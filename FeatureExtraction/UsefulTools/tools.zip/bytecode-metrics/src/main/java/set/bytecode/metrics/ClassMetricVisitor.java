package set.bytecode.metrics;

import java.util.HashSet;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

class ClassMetricVisitor extends ClassVisitor implements Opcodes
{
	static int index = 0;
	String cName;

	public ClassMetricVisitor() {
		super(ASM5);
	}

	public void visit(int version, int access, String name, String signature,
			String superName, String[] interfaces) {
		this.cName = name;
		MainAnalyzer.classCount++;
	}

	public MethodVisitor visitMethod(int access, String name, String desc,
			String signature, String[] exceptions) {
		MethodVisitor mv = super.visitMethod(access, name, desc, signature,
				exceptions);
		String mName = cName.replace("/", ".") + "." + (name + desc);
		MetricData data= new MetricData();
		MainAnalyzer.metrics.put(mName, data);
		return new MethodMetricVisitor(mv, mName, data);
	}
}
