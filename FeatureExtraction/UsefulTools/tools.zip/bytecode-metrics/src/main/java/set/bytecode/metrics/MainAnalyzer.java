package set.bytecode.metrics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;

public class MainAnalyzer
{
	public static Map<String, MetricData> metrics = new HashMap<String, MetricData>();
	public static int classCount = 0;

	/**
	 * Main function, take a class directory or jar file as input, and analyze
	 * all class files under it
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		long start_time = System.currentTimeMillis();
		metrics.clear();
		classCount = 0;

		String path = args[0];
		String outPath = args[1];
		if (path.endsWith(".jar"))
			analyzeMetric(new JarFile(path));
		else
			analyzeMetric(path);
		serialize(outPath);
		long end_time = System.currentTimeMillis();
		System.out.println("Metric analysis analyzed " + classCount
				+ " classes using: " + (end_time - start_time) + " ms");
	}

	public static void serialize(String path) throws IOException {
		PrintStream printer = new PrintStream(path);
		for (String m : metrics.keySet()) {
			printer.println(m + " " + metrics.get(m).toString());
		}
		printer.close();
	}

	public static void analyzeMetric(String dir) throws IOException, Exception {
		File dirFile = new File(dir);
		List<File> workList = new ArrayList<File>();
		workList.add(dirFile);
		while (!workList.isEmpty()) {
			File curF = workList.remove(0);
			if (curF.getName().endsWith(".class")) {
				InputStream classFileInputStream = new FileInputStream(curF);
				ClassReader cr = new ClassReader(classFileInputStream);
				ClassMetricVisitor ca = new ClassMetricVisitor();
				cr.accept(ca, 0);
				classFileInputStream.close();
			} else if (curF.isDirectory()) {
				for (File f : curF.listFiles())
					workList.add(f);
			}
		}
	}

	public static void analyzeMetric(JarFile f) throws IOException {
		Enumeration<JarEntry> entries = f.entries();
		while (entries.hasMoreElements()) {
			JarEntry entry = entries.nextElement();

			String entryName = entry.getName();
			if (entryName.endsWith(".class")) {
				InputStream classFileInputStream = f.getInputStream(entry);
				ClassReader cr = new ClassReader(classFileInputStream);
				ClassMetricVisitor ca = new ClassMetricVisitor();
				cr.accept(ca, 0);
				classFileInputStream.close();
			}
		}
	}

	private static ClassNode parseClassNode(final String classFileName)
			throws IOException, FileNotFoundException {
		final ClassReader cr = new ClassReader(
				new FileInputStream(classFileName));
		// create an empty ClassNode (in-memory representation of a class)
		final ClassNode clazz = new ClassNode();
		// have the ClassReader read the class file and populate the ClassNode
		// with the corresponding information
		cr.accept(clazz, 0);
		return clazz;
	}

}
