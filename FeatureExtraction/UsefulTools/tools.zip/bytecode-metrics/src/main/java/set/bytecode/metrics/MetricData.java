package set.bytecode.metrics;

public class MetricData
{
	public int numFrame = 0;
	public int numInsn = 0;
	public int numIntInsn = 0;
	public int numVarInsn = 0;
	public int numTypeInsn = 0;
	public int numFieldInsn = 0;
	public int numMethInsn = 0;
	public int numInvokeDynamicInsn = 0;
	public int numJumpInsn = 0;
	public int numLabelInsn = 0;
	public int numLdcInsn = 0;
	public int numIincInsn = 0;
	public int numTableSwitchInsn = 0;
	public int numLookupSwitchInsn = 0;
	public int numMultiANewArrayInsn = 0;
	public int numTryCatchBlock = 0;

	public static final String sep = " ";

	public String toString() {
		return numFrame + sep + numInsn + sep + numIntInsn + sep + numVarInsn
				+ sep + numTypeInsn + sep + numFieldInsn + sep + numMethInsn
				+ sep + numInvokeDynamicInsn + sep + numJumpInsn + sep
				+ numLabelInsn + sep + numLdcInsn + sep + numIincInsn + sep
				+ numTableSwitchInsn + sep + numLookupSwitchInsn + sep
				+ numMultiANewArrayInsn + sep + numTryCatchBlock;
	}
}
