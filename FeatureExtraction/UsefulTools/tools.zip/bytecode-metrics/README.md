# README #

This readme shows how to build and run the bytecode metrics tool based on ASM.

### Build ###

* git clone "the project git repo"
* cd to the project directory, and type
`mvn package'
* You will see a jar file named "bytecode-metrics-0.0.1-SNAPSHOT.jar" if the build succeeded

### Run analysis ###

* The main class for the project is "set.bytecode.metrics.MainAnalyzer". It takes only two parameters:
	+	The directory under analysis, e.g., project-path/target/classes
	+	The file for storing the metric data
* To invoke the main class, simply do:
java -jar "path-of-bytecode-metrics-0.0.1-SNAPSHOT.jar" "path-of-target-directory" "path-of-output-file"

### Metrics analyzed ###
Herer are the 16 bytecode metrics analyzed for each method:

	*	public int numFrame
	*	public int numInsn 
	*	public int numIntInsn 
	*	public int numVarInsn 
	*	public int numTypeInsn
	*	public int numFieldInsn 
	*	public int numMethInsn 
	*	public int numInvokeDynamicInsn
	*	public int numJumpInsn
	*	public int numLabelInsn 
	*	public int numLdcInsn 
	*	public int numIincInsn 
	*	public int numTableSwitchInsn 
	*	public int numLookupSwitchInsn 
	*	public int numMultiANewArrayInsn 
	*	public int numTryCatchBlock

### Example output ###
* The tool is extremely fast: It takes around 350ms to analyze all the bytecode files for commons-math
* Here are some lines of the metric file generated for commons-math, each line starts with the method name followed by the metric values
```
org.apache.commons.math4.complex.ComplexTest.testPowNaNBase()V 0 2 0 2 1 1 0 0 0 6 0 0 0 0 0 0
org.apache.commons.math4.util.Combinations.comparator()Ljava/util/Comparator; 0 2 0 2 1 2 0 0 0 2 0 0 0 0 0 0
org.apache.commons.math4.util.Decimal64.linearCombination(DLjava/lang/Object;DLjava/lang/Object;)Ljava/lang/Object; 0 1 0 5 2 0 0 0 0 2 0 0 0 0 0 0
org.apache.commons.math4.linear.BiDiagonalTransformerTest.testBBiDiagonal()V 0 4 0 6 3 3 0 0 0 5 0 0 0 0 0 0
org.apache.commons.math4.analysis.polynomials.PolynomialFunctionLagrangeFormTest.testQuadraticFunction()V 0 34 2 40 1 0 0 0 0 35 0 0 0 0 0 0
org.apache.commons.math4.analysis.differentiation.DerivativeStructureTest.testToRadiansDefinition()V 8 19 3 22 1 0 0 0 8 26 0 2 0 0 0 0
org.apache.commons.math4.ode.nonstiff.HighamHall54IntegratorTest$2.resetState(D[D)V 0 1 0 0 0 0 0 0 0 2 0 0 0 0 0 0
org.apache.commons.math4.geometry.euclidean.twod.PolygonsSetTest$Counter$1.visitLeafNode(Lorg/apache/commons/math4/geometry/partitioning/BSPTree;)V 0 4 0 1 0 1 0 0 0 3 0 0 0 0 0 0
org.apache.commons.math4.linear.ArrayFieldVector.walkInOptimizedOrder(Lorg/apache/commons/math4/linear/FieldVectorPreservingVisitor;II)Lorg/apache/commons/math4/FieldElement; 0 1 0 4 0 0 0 0 0 2 0 0 0 0 0 0
```
### Contacts ###

* Lingming Zhang
* Xia Li