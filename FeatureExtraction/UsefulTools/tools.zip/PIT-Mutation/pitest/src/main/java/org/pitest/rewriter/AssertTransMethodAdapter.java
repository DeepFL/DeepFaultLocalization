package org.pitest.rewriter;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/**
 * The class to perform changes for each method in each loaded class
 * @author lingmingzhang
 *
 */

public class AssertTransMethodAdapter extends MethodVisitor {
	String classname;
	String testname;
	int curLine = -1;
	int access;
	boolean testcase = false;
	
	
	static final String columnSeperator = "\t";
	public static Map<String, Set<String>> assertionDictionary = new HashMap<String, Set<String>>();
	
	static Set<Integer> returns = new HashSet<Integer>(); 

	static {
		Collections.addAll(returns, Opcodes.IRETURN, Opcodes.RETURN, Opcodes.LRETURN, Opcodes.FRETURN, Opcodes.DRETURN, Opcodes.ARETURN);
		
		Set<String> descSet = new HashSet<String>();
		
		Collections.addAll(descSet, "(Ljava/lang/String;Z)V", "(Z)V");
		assertionDictionary.put("assertTrue", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;Z)V", "(Z)V");
		assertionDictionary.put("assertFalse", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;)V", "()V");
		assertionDictionary.put("fail", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;[Ljava/lang/Object;[Ljava/lang/Object;)V","([Ljava/lang/Object;[Ljava/lang/Object;)V",
"(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V"
				, "(Ljava/lang/Object;Ljava/lang/Object;)V", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"
				, "(Ljava/lang/String;Ljava/lang/String;)V", "(Ljava/lang/String;DDD)V",
				"(DDD)V", "(Ljava/lang/String;FFF)V", "(FFF)V", "(Ljava/lang/String;JJ)V", "(JJ)V","(Ljava/lang/String;ZZ)V"
				, "(ZZ)V", "(Ljava/lang/String;BB)V", "(BB)V", "(Ljava/lang/String;CC)V", "(CC)V", "((Ljava/lang/String;SS)V"
				,"(SS)V", "(Ljava/lang/String;II)V", "(II)V");
		
		assertionDictionary.put("assertEquals", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/Object;)V", "(Ljava/lang/String;Ljava/lang/Object;)V");
		assertionDictionary.put("assertNotNull", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/Object;)V", "(Ljava/lang/String;Ljava/lang/Object;)V");
		assertionDictionary.put("assertNull", new HashSet<String>(descSet));
		descSet.clear();

		Collections.addAll(descSet, "(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V", "(Ljava/lang/Object;Ljava/lang/Object;)V");
		assertionDictionary.put("assertSame", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V", "(Ljava/lang/Object;Ljava/lang/Object;)V");
		assertionDictionary.put("assertNotSame", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V");
		assertionDictionary.put("failNotSame", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V");
		assertionDictionary.put("failNotEquals", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;[Ljava/lang/Object;[Ljava/lang/Object;)V"
				, "([Ljava/lang/Object;[Ljava/lang/Object;)V", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"
				, "(Ljava/lang/String;[B[B)V", "([B[B)V","(Ljava/lang/String;[D[DD)V",
				"([D[DD)V", "(Ljava/lang/String;[F[FF)V", "([F[FF)V", "(Ljava/lang/String;[J[J)V", "([J[J)V","(Ljava/lang/String;[Z[Z)V"
				, "([Z[Z)V",   "(Ljava/lang/String;[C[C)V", "([C[C)V", "((Ljava/lang/String;[S[S)V"
				,"([S[S)V", "(Ljava/lang/String;[I[I)V", "([I[I)V");
		assertionDictionary.put("assertArrayEquals", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/String;)V");
		assertionDictionary.put("failSame", new HashSet<String>(descSet));
		descSet.clear();
		
		Collections.addAll(descSet, "(Ljava/lang/Object;Lorg/hamcrest/Matcher;Ljava/lang/String;)V","(Ljava/lang/String;Ljava/lang/Object;Lorg/hamcrest/Matcher;Ljava/lang/String;)V");
		assertionDictionary.put("assertThat", new HashSet<String>(descSet));
		descSet.clear();
	}

	public AssertTransMethodAdapter(MethodVisitor m, int access,
			String classname) {
		super(Opcodes.ASM5, m);
		this.classname = classname;
		this.access = access;
	}

	@Override
	public void visitLineNumber(int line, Label start) {
		mv.visitLineNumber(line, start);
		curLine = line;
	}

	@Override
	public void visitMethodInsn(final int opcode, final String owner,
			final String name, final String desc, boolean bool) {
		if (shouldTransform(desc, name, owner, opcode)) {
			// pass the assertion location (line) to the modified version
			mv.visitLdcInsn(this.classname.replace("/", ".") + ":" + curLine
					+ ":" + name + "\n");
			// prior: int, int, modified stack: int, int, String; thus, need add a string type parameter to desc 
			mv.visitMethodInsn(opcode, Properties.REWRITER_CLASS_NAME, name,
					getNewDesc(desc), bool);
		} else {
			mv.visitMethodInsn(opcode, owner, name, desc, bool);

		}
	}

	public  boolean shouldTransform(String desc, String methodName, String owner, int opcode) {
		if (assertionDictionary.containsKey(methodName)){
			if ( ("org/junit/Assert".equals(owner)) || ("junit/framework/Assert".equals(owner)) || opcode == Opcodes.INVOKESTATIC) {
				if ("assertThat".equals(methodName)) return true;
				if (assertionDictionary.get(methodName).contains(desc))
					return true;
			}
		}
		return false;
	}

	// add a string type parameter to the method signature
	public String getNewDesc(String desc) {
		return desc.substring(0, desc.length() - 2) + "Ljava/lang/String;)V";
	}

	public void visitMaxs(int maxStack, int maxLocals) {
		
		mv.visitMaxs(maxStack, maxLocals);
	}
}
