package org.pitest.mutationtest.report.mutantcoverage;

import org.pitest.mutationtest.ListenerArguments;
import org.pitest.mutationtest.MutationResultListener;
import org.pitest.mutationtest.MutationResultListenerFactory;

public class MutantCoverageReportFactory implements MutationResultListenerFactory{

	public String description() {
		return "Mutant Coverage plugin";
	}

	public MutationResultListener getListener(ListenerArguments args) {
		return new MutantCoverageListener(args);
	}

	public String name() {
		return "MutantCoverageReporter";
	}

}
