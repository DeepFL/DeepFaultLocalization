package org.pitest.coverage.execute;

import org.pitest.testapi.Description;
import org.pitest.testapi.TestListener;
import org.pitest.testapi.TestResult;

public class ErrorListener implements TestListener {
	public boolean pass=true;
	public String errorMsg="PASS";

  public void onRunStart() {
  }

  public void onTestStart(final Description d) {
  }

  public void onTestFailure(final TestResult tr) {
	  pass=false;
	  errorMsg=tr.getFailureMsg();
    System.out.println("FAIL " + tr.getDescription() + " -> "
        + tr.getThrowable());
  }

  public void onTestSkipped(final TestResult tr) {
  }

  public void onTestSuccess(final TestResult tr) {

  }

  public void onRunEnd() {
  }

}
