package org.pitest.rewriter;

import java.util.logging.Logger;

import org.pitest.util.Log;



public class Properties {
	private final static Logger                LOG = Log.getLogger();
	public static final String PROJECT_PREFIX_KEY = "prefix";
	public static final String ASSERT_TRANS_KEY = "rewriter.trans";
	public static final String REWRITER_DIR = "assert-files";

	public static String PROJECT_PREFIX = getProperty(PROJECT_PREFIX_KEY);
	public static boolean ASSERT_TRANS = getPropertyOrDefault(ASSERT_TRANS_KEY, true);

	public static final String REWRITER_CLASS_NAME = "org/pitest/rewriter/Rewriter";

	private static String getProperty(String key) {

		String result = null;
		if (System.getProperty(key) != null) {
			result = System.getProperty(key);
		}
		// no else if - property may also be null
		return result;
	}

	public static boolean getPropertyOrDefault(String key, boolean defaultValue) {
		String property = getProperty(key);
//		logger.debug(key + "-" + property);
		if (property != null) {
			String propertyTrimmed = property.trim().toLowerCase();
			if (propertyTrimmed.equals("true") || propertyTrimmed.equals("yes")) {
				return true;
			} else if (propertyTrimmed.equals("false")
					|| propertyTrimmed.equals("no")) {
				return false;
			}
		}
		return defaultValue;
	}
}
