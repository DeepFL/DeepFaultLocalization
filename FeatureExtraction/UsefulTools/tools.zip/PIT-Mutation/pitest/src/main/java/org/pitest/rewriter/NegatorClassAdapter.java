package org.pitest.rewriter;

import java.util.logging.Logger;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.pitest.util.Log;

/**
 * The main class to perform changes on each class loaded into JVM
 * @author lingmingzhang
 *
 */

public class NegatorClassAdapter extends ClassVisitor {
	private final static Logger LOG = Log.getLogger();
	String name;

	public NegatorClassAdapter(ClassVisitor cv) {
		super(Opcodes.ASM5, cv);
	}

	@Override
	public void visit(final int version, final int access, final String name,
			final String signature, final String superName,
			final String[] interfaces) {
		this.name = name;
		cv.visit(version, access, name, signature, superName, interfaces);
	}

	@Override
	public MethodVisitor visitMethod(int access, String name, String desc,
			String signature, String[] exceptions) {
		MethodVisitor mv = cv.visitMethod(access, name, desc, signature,
				exceptions);

		mv = new AssertTransMethodAdapter(mv, access, this.name + ":" + name
				+ ":" + desc);

		return mv;
	}

}
