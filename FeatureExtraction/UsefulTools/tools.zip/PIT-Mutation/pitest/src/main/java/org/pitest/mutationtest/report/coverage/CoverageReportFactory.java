package org.pitest.mutationtest.report.coverage;

import org.pitest.mutationtest.ListenerArguments;
import org.pitest.mutationtest.MutationResultListener;
import org.pitest.mutationtest.MutationResultListenerFactory;

public class CoverageReportFactory implements MutationResultListenerFactory{

	public String description() {
		return "Coverage report plugin";
	}

	public MutationResultListener getListener(ListenerArguments args) {
		return new CoverageReportListener(args);
	}

	public String name() {
		return "CoverageReporter";
	}

}
