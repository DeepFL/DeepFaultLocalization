package org.pitest.mutationtest.report.mutantcoverage;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.pitest.coverage.TestInfo;
import org.pitest.mutationtest.ClassMutationResults;
import org.pitest.mutationtest.ListenerArguments;
import org.pitest.mutationtest.MutationResult;
import org.pitest.mutationtest.MutationResultListener;
import org.pitest.mutationtest.engine.MutationDetails;
import org.pitest.util.Unchecked;

public class MutantCoverageListener implements MutationResultListener {

	private ListenerArguments listenerArguments;
	private final Writer out;
	
	private List<MutationDetails> mutationDetailList = new ArrayList<MutationDetails>();
	
	public MutantCoverageListener(Writer out) {
		this.out = out;
	}
	
	public MutantCoverageListener(ListenerArguments args) {
		this(args.getOutputStrategy().createWriterForFile("mutation_coverage_matrix.csv"));
		this.listenerArguments = args;
	}
	
	public void runStart() {

	}

	public void handleMutationResult(ClassMutationResults results) {
		for (MutationResult mutationResult : results.getMutations()) {
			this.mutationDetailList.add(mutationResult.getDetails());
		}
	}

	public void runEnd() {
//		Map<TestInfo, Integer> testMap = new HashMap<TestInfo, Integer>();
//		List<TestInfo> testList = new ArrayList<TestInfo>();
		
//		int count = 0;
//		for (MutationDetails mutationDetail : this.mutationDetailList) {
//			for (TestInfo testInfo : mutationDetail.getTestsInOrder()) {
//				if (!testMap.containsKey(testInfo)) {
//					testMap.put(testInfo, count++);
//					testList.add(testInfo);
//				}
//			}
//		}
		
		try {
			// Restore the test information in file
//			Writer testInfoWriter = this.listenerArguments
//					.getOutputStrategy().createWriterForFile("test_index.txt");
			
			Writer textInfoWriter = this.listenerArguments
					.getOutputStrategy().createWriterForFile("text_coverage.txt");
			
//			Writer mutantWriter = this.listenerArguments
//					.getOutputStrategy().createWriterForFile("mutant_index.txt");
			
//			for (MutationDetails mutationDetail : this.mutationDetailList)
//				mutantWriter.write(mutationDetail.getClassName() + ":" + mutationDetail.getFilename() + ":" + mutationDetail.getMethod().name() 
//				+ ":" + mutationDetail.getLineNumber() + "\n");
//			
//			for (Entry<TestInfo, Integer> entry : testMap.entrySet()) {
//				testInfoWriter.write(entry.getKey().getName() + ":" + entry.getValue() + "\n");
//			}
//			testInfoWriter.close();

			// Generate the matrix
			for (MutationDetails mutationDetail : this.mutationDetailList) {
//				String line = getCsvLine(mutationDetail, testList);
//				this.out.write(line);
				
				//
				textInfoWriter.write(getTextLine(mutationDetail));
			}
			
			
//			mutantWriter.close();
			textInfoWriter.close();
			this.out.close();
			
		}catch (final IOException e) {
			throw Unchecked.translateCheckedException(e);
		}
	}

	private String getTextLine(MutationDetails mutationDetail) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(mutationDetail.getClassName() + ":" + mutationDetail.getMethod().name() 
		+ ":" + mutationDetail.getLineNumber() + ":" + mutationDetail.getMutator() + " ");
		
		for (TestInfo testInfo : mutationDetail.getTestsInOrder()) {
			stringBuilder.append(testInfo);
			stringBuilder.append(",");
		}
		
		return stringBuilder.toString() + "\n";
	}

	private String getCsvLine(MutationDetails mutationDetail, List<TestInfo> testList) {
		StringBuilder stringBuilder = new StringBuilder();
		Set<TestInfo> testSetPerMutant = new HashSet<TestInfo>();
		
		for (TestInfo testInfo : mutationDetail.getTestsInOrder())
			testSetPerMutant.add(testInfo);
		
		for (TestInfo testInfo : testList) {
			if (testSetPerMutant.contains(testInfo)) {
				stringBuilder.append("1");
			}
			else
				stringBuilder.append("0");
		}
		
		return stringBuilder.toString() + "\n";
	}

}