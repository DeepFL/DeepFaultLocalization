package org.pitest.rewriter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.codec.digest.DigestUtils;
import org.pitest.mutationtest.execute.MutationTestWorker;

public class Serializer
{
	private static final String MUT_DIRECTORY = "mutation-test";
	private static final String COV_DIRECTORY = "coverage-test";
	private static List<String> list = new ArrayList<String>();
	private static Set<String> tracedAsserts = new HashSet<String>();
	static final String SEP=" ";
	public static final String EXP="[EXCEPTION]";
	public static final String STRACE="[STACKTRACE]";
	

	public static void serializeCoverage(String desc) {
		try {
			list.add(desc);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void serialize(String desc, boolean value, String content) {
		try {
			String assertId = desc.trim();
			if (MutationTestWorker.testUnit != null)
				assertId = desc.trim() +SEP + MutationTestWorker.testUnit
						.getDescription().getQualifiedName();
			String key;
			// keep complete exception info
			if (desc.equals(EXP))
				key = assertId + SEP + value + SEP + content;
			else
				key = assertId + SEP + value + SEP
						+ DigestUtils.md5Hex(content);
			if (!tracedAsserts.contains(assertId)) {
				list.add(key);
				tracedAsserts.add(assertId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeCoverageResult(int instanceCount,
			boolean testOutcome, String stackTrace) {
		PrintWriter serializer = null;
		try {
			String fileName = COV_DIRECTORY + File.separator + instanceCount;
			File outputDir = new File(COV_DIRECTORY);
			if (!outputDir.exists())
				outputDir.mkdir();

			serializer = new PrintWriter(new File(fileName));

			serializer.write(list.get(0) + SEP + testOutcome + SEP
					+ (stackTrace) + "\n");
			// writer assertion id and outcome
			for (int i = 1; i < list.size(); i++) {
				String item = list.get(i);
				serializer.write(item + "\n");
			}
			serializer.flush();

			list.clear();
			tracedAsserts.clear();

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			serializer.close();
		}
	}

	public static void writeResult(String result, int instanceCount) {
		BufferedWriter serializer = null;
		try {
			String fileName = MUT_DIRECTORY + File.separator
					+ MutationTestWorker.mutationDetails.getId().getClassName()
					+ "." + MutationTestWorker.mutationDetails.getLineNumber()
					+ "." + MutationTestWorker.mutationDetails.getFirstIndex()
					+ System.nanoTime() + instanceCount;
			File outputDir = new File(MUT_DIRECTORY);
			if (!outputDir.exists())
				outputDir.mkdir();

			GZIPOutputStream zip = new GZIPOutputStream(
					new FileOutputStream(new File(fileName + ".cover.gz")));

			serializer = new BufferedWriter(
					new OutputStreamWriter(zip, "UTF-8"));

			serializer.write(
					MutationTestWorker.mutationDetails.toString() + "\n");

			for (String item : list) {
				serializer.write(item + "\n");
			}
			serializer.write(result);
			serializer.flush();

			list.clear();
			tracedAsserts.clear();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				serializer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}