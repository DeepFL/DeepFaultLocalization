package org.pitest.rewriter;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.pitest.util.Log;


public class ClassTransformer implements ClassFileTransformer {

	private final static Logger                LOG = Log.getLogger();
	
	private String whiteList = null;
	
	public byte[] transform(ClassLoader loader, String className,
			Class<?> classBeingRedefined, ProtectionDomain protectionDomain,
			byte[] classfileBuffer) throws IllegalClassFormatException {
		
		try {
			if (className == null) {
				return classfileBuffer;
			}
			if (loader != ClassLoader.getSystemClassLoader()) {
				return classfileBuffer;
			}
			
			if (this.whiteList == null || !className.startsWith(this.whiteList)) {
				return classfileBuffer;
			}

			byte[] result = classfileBuffer;
			ClassReader reader = new ClassReader(classfileBuffer);
			//bug fix: compute_frames to compute_maxs
			ClassWriter writer = new ClassWriter(
					org.objectweb.asm.ClassWriter.COMPUTE_MAXS);
			ClassVisitor cv = writer;

			cv = new NegatorClassAdapter(cv);
			reader.accept(cv, ClassReader.EXPAND_FRAMES);
			result = writer.toByteArray();
			return result;

		} catch (Throwable t) {
			t.printStackTrace();
			String message = "Exception thrown during instrumentation";
			System.err.println(message);
			System.exit(1);
		}
		throw new RuntimeException("Should not be reached");
	}
	
	public ClassTransformer() {
		
		BufferedReader br = null;

		try {
			if (whiteList != null) return;
			String sCurrentLine;

			br = new BufferedReader(new FileReader("prefix.conf"));

			while ((sCurrentLine = br.readLine()) != null) {
				whiteList = sCurrentLine;
				LOG.info("=======================conf read:" + whiteList);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}


}
