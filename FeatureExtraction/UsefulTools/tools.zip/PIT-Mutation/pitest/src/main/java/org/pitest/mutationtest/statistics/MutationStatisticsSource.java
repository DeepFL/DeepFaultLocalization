package org.pitest.mutationtest.statistics;

public interface MutationStatisticsSource {
  MutationStatistics getStatistics();
}
