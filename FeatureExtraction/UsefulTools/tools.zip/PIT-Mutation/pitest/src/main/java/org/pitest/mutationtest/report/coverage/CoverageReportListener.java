package org.pitest.mutationtest.report.coverage;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.pitest.coverage.BlockLocation;
import org.pitest.coverage.CoverageDataLineToClass;
import org.pitest.coverage.CoverageDatabase;
import org.pitest.coverage.TestInfo;
import org.pitest.mutationtest.ClassMutationResults;
import org.pitest.mutationtest.ListenerArguments;
import org.pitest.mutationtest.MutationResultListener;
import org.pitest.util.Unchecked;

public class CoverageReportListener implements MutationResultListener{

	private final Writer out;
	private ListenerArguments listenerArguments;
	
	public CoverageReportListener(ListenerArguments args) {
		this(args.getOutputStrategy().createWriterForFile("mutations_coverage.csv"));
		this.listenerArguments = args;
	}

	public CoverageReportListener(Writer out) {
		this.out = out;
	}

	public void runStart() {
		
	}

	public void handleMutationResult(ClassMutationResults results) {
		
	}

	public void runEnd() {
	    try {
	    	CoverageDatabase coverageData = this.listenerArguments.getCoverage();
	    	
	    	if (coverageData instanceof CoverageDataLineToClass) {
	    		CoverageDataLineToClass coverageDataLineToClass = (CoverageDataLineToClass)coverageData;
	    		
	    		Map<TestInfo, Set<BlockLocation>> testToBlockLocationMap =  coverageDataLineToClass.getTestToClassLine();
	    		Map<BlockLocation, Set<Integer>> blockLineMap = coverageDataLineToClass.getBlockLineMap();
	    		for (Entry<TestInfo, Set<BlockLocation>> entry : testToBlockLocationMap.entrySet()) {
	    			this.out.write(getCsvLine(entry.getKey(), entry.getValue(), blockLineMap));
	    		}
	    	}
	    	else
	    		throw new RuntimeException("Do not get the right linstener object");
	    	
	        this.out.close();
	      } catch (final IOException e) {
	        throw Unchecked.translateCheckedException(e);
	      }
	}

	private String getCsvLine(TestInfo key, Set<BlockLocation> value, Map<BlockLocation, Set<Integer>> blockLineMap) {
		StringBuilder csvLine = new StringBuilder();
		
		csvLine.append(key.getName() + " ");
		
		for (BlockLocation blockLocation : value) {
			Set<Integer> lineSet = blockLineMap.get(blockLocation);
			if (lineSet == null) 
				continue;
			
			for (Integer line : lineSet) {
				csvLine.append(blockLocation.getLocation().getClassName() + ":" 
						+ blockLocation.getLocation().getMethodName() + ":"
						+ line);
				csvLine.append(",");
			}
		}
		csvLine.append("\n");
		
		return csvLine.toString();
	}
}
