mvn -e -DpreparationGoals=clean,test release:prepare
