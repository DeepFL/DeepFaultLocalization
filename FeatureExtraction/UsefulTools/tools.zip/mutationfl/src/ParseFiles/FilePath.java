package ParseFiles;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import Main.RunMain;

public class FilePath {
	public static String rootPath = RunMain.rootDirPath;
	public static String Failingpath = rootPath + "UsefulData/FailingTests/";
    public static String LineCoveragePath = rootPath + "RawFeatures/Spectrum/";
	public static String MethodPath = rootPath + "UsefulData/AllMethods/";
    public static String Bugpath = rootPath + "UsefulData/BugMethod/";  
    public static String ResutPath = rootPath + "FeatureValues/";  
	
    public static String MutationData = rootPath + "RawFeatures/Mutation/";	
    public static String FailMessage = rootPath + "UsefulData/defects4j/framework/projects/";
    public static String ProjectsPath = rootPath + "SubjectExample/";
    public static String InformationRData = rootPath + "RawFeatures/Textual/";
    
    public static String MetricXMLfile = rootPath + "RawFeatures/Complexity/";
    
    public static String MutatorPath=rootPath+"/MutatorData/";
    public static String ByteMetricPath=rootPath+"/ByteMetricData/";
    public static String JhawkPath = rootPath + "FeatureValues/Complexity/";
    public static String FluccsBytePath=rootPath+"/FluccsByteData/";
    public static String FluccsJhawkPath=rootPath+"/FluccsJhawkData/";
    public static String IRDataPath=rootPath+"/IRData/";
    public static String aggreSpectrumDataPath=rootPath+"/aggreSpectrumData/";
    public static String findbugsPath=rootPath+"/findbugsData/";
}
