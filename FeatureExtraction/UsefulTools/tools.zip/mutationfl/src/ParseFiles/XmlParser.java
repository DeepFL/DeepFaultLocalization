package ParseFiles;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.lang.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;



public class XmlParser {

	public static HashMap<String,String> ParseXML(String XMLPath,String Level) throws IOException{
		HashMap<String,String> Levelsandmetricvalues=new HashMap<String,String>();
		
		try{
			File inputFile = new File(XMLPath);
			DocumentBuilderFactory dbFactory= DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			
			
			if(Level.equals("Method")){
				NodeList nList = doc.getElementsByTagName("Method");
				Levelsandmetricvalues=ParseMethod(nList);
				
			}else if(Level.equals("Class")){
				NodeList nList = doc.getElementsByTagName("Class");
				Levelsandmetricvalues=ParseClassOrPackage(nList,"Class");
				
			}else if(Level.equals("Package")){
				NodeList nList = doc.getElementsByTagName("Package");
				Levelsandmetricvalues=ParseClassOrPackage(nList,"Package");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Levelsandmetricvalues;
		
	}
	public static HashMap<String,String> ParseClassOrPackage(NodeList nList,String cOrp) throws IOException{
		HashMap<String,String> Cpandmetricvalues=new HashMap<String,String>();
		try{
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if(cOrp.equals("Class")){
						String PackageName=eElement.getElementsByTagName("OwningPackage").item(0).getTextContent();
						String ClassName=eElement.getElementsByTagName("ClassName").item(0).getTextContent();
						String MetricValues=GetMethodandMetricValues(eElement);
						Cpandmetricvalues.put(PackageName+"."+ClassName,MetricValues);  
					}else if(cOrp.equals("Package")){
						String Name=eElement.getElementsByTagName("Name").item(0).getTextContent();
						String MetricValues=GetMethodandMetricValues(eElement);
						Cpandmetricvalues.put(Name,MetricValues);
					}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Cpandmetricvalues;
	}

	public static HashMap<String,String> ParseMethod(NodeList nList) throws IOException{
		
		HashMap<String,String> Methodandmetricvalues=new HashMap<String,String>();
		
		try {	
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					
					String ClassName=eElement.getElementsByTagName("ClassName").item(0).getTextContent();
					String mName=eElement.getElementsByTagName("Name").item(0).getTextContent();
					String MethodName="";
					
					int lastindex=0;
					if(ClassName.contains("$")) //inner class
						lastindex=ClassName.lastIndexOf("$");
					else
						lastindex=ClassName.lastIndexOf(".");
					if(ClassName.substring(lastindex+1,ClassName.length()).equals(mName))
						MethodName=ClassName+".<init>";
					else
						MethodName=ClassName+"."+mName;
					String Args=(String)GetMethodandargs(eElement).get(0);    //arguments
					HashMap<String,String> RefClassMap=(HashMap)GetMethodandargs(eElement).get(1);
					//Methodandmetricvalues.get(MethodName)[1]=returnTypes;			//return value
					String MetricValues=GetMethodandMetricValues(eElement);
					
					String Rawreturns=eElement.getElementsByTagName("ReturnValue").item(0).getTextContent();
					String CleanReturns=RefClassMatch(Rawreturns,RefClassMap);
					
					String key=MethodName+"+++"+Args.trim()+"+++"+CleanReturns;
					
					Methodandmetricvalues.put(key,MetricValues);  
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	
		return Methodandmetricvalues;
	}
	public static String RefClassMatch(String Rawreturns,HashMap<String,String> RefClassMap){
		String CleanReturns="";
		if(Rawreturns.contains("<")){
			String oldreturnName=Rawreturns.split("<")[0];
			String returnName="";
			if(oldreturnName.contains(".")){
				int lastdot=oldreturnName.lastIndexOf(".");
				returnName=oldreturnName.substring(lastdot+1, oldreturnName.length());
			}else
				returnName=oldreturnName;
			
			String others="";
			if(Rawreturns.split(">").length>1&&Rawreturns.split(">")[1].contains("[]"))
				others=Rawreturns.split(">")[1];
			
			if(RefClassMap.containsKey(returnName))
				CleanReturns=RefClassMap.get(returnName)+others;
			else
				CleanReturns=returnName+others;
		}else if(Rawreturns.contains("[")){
				String returnName=Rawreturns.split("\\[")[0];
				String app=Rawreturns.split("\\[")[1];
				if(RefClassMap.containsKey(returnName))
					CleanReturns=RefClassMap.get(returnName)+"["+app;
				else
					CleanReturns=Rawreturns;
		}else{
			if(RefClassMap.containsKey(Rawreturns))   //JSType...
				CleanReturns=RefClassMap.get(Rawreturns);
			else
				CleanReturns=Rawreturns;
		}
		return CleanReturns;
	}
	public static ArrayList<Object> GetMethodandargs(Element eElement){
		Node metriNode = eElement.getElementsByTagName("Metrics").item(0);
		Element metricElement = (Element) metriNode;
		
		HashMap<String,String> RefClassMap=new HashMap<String,String>();//"EXM"--->"org.apache.time.EXM"
																		//Since some arguments only have name "EXM"
		if(metricElement.getElementsByTagName("classesReferenced").getLength()>0){
			Node ClassREFNode=metricElement.getElementsByTagName("classesReferenced").item(0);
			Element ClassREFElement=(Element)ClassREFNode;
			NodeList ClassREFList=ClassREFElement.getElementsByTagName("classReferenced");
			for(int REFID=0;REFID<ClassREFList.getLength();REFID++){
				Node aNode=ClassREFList.item(REFID);
				Element an=(Element)aNode;
				String ReferencedClass=an.getAttribute("K");
				int lastDotIndex=ReferencedClass.lastIndexOf(".");
				String OnlyClass=ReferencedClass.substring(lastDotIndex+1,ReferencedClass.length());
				RefClassMap.put(OnlyClass,ReferencedClass);
				
			}
		}
		
		
		StringBuilder arguments=new StringBuilder();
		if(metricElement.getElementsByTagName("arguments").getLength()>0){
			Node argNode=metricElement.getElementsByTagName("arguments").item(0);
			Element argElement=(Element)argNode;
			NodeList argList=argElement.getElementsByTagName("argument");
			//ArrayList<String> arguments=new ArrayList<String>();
			for(int argID=0;argID<argList.getLength();argID++){
				Node aNode=argList.item(argID);
				Element an=(Element)aNode;
				String OneArg=an.getAttribute("V");
				String CleanOneArg="";
				String Matcher="\\w+\\.\\.\\.";
				if(OneArg.matches(Matcher)){
					String clean=RefClassMatch(OneArg.split("\\.\\.\\.")[0],RefClassMap);
					CleanOneArg=clean+"...";
				}
				else{
					CleanOneArg=RefClassMatch(OneArg,RefClassMap);
				}
			
				arguments.append(CleanOneArg+" ");
			}
		}
		
		ArrayList<Object> Infor=new ArrayList<Object>();
		Infor.add(arguments.toString());
		Infor.add(RefClassMap);
		return Infor;
		
	}
	public static String GetMethodandMetricValues(Element eElement) throws IOException{
		NodeList metricNodes=eElement.getElementsByTagName("Metrics").item(0).getChildNodes();
		
		StringBuilder AllMetrics=new StringBuilder();
		for(int metricID=0;metricID<metricNodes.getLength();metricID++){
			String metricName=metricNodes.item(metricID).getNodeName();
			String metrivValue=metricNodes.item(metricID).getTextContent();
			if(!metricName.equals("#text")&&idDouble(metrivValue)){
				AllMetrics.append(metricName+":"+metrivValue+" ");
			}
		}
		return AllMetrics.toString();
		
	}
	public static boolean idDouble(String s) {
		boolean isValidDouble = false;
		try{
			Double.parseDouble(s);
	        isValidDouble = true;
		}catch (NumberFormatException ex){
			// s is not an double
		}
		return isValidDouble;
	}
}

