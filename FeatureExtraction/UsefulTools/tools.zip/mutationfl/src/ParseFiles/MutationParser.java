/*
 * Parse mutation-test and mutation-coverage files
 * 
 * 
 */

package ParseFiles;

import java.util.*;
import java.util.zip.GZIPInputStream;
import java.io.*;
import Main.*;
import org.apache.commons.lang3.*;

public class MutationParser {
	
	
	public static String fileType="";
	public static ArrayList<String> AllMutators=new ArrayList<String>();
	
	
	public static List<Object> AssertParser(String path,Map<String, Set<String>> AssertCoverage,List<Object> ParseInfor,
												List<String> FailingTest) throws IOException{
		//mutant and its tests/asertions
		Map<String, ArrayList<String>> MutantAssertions=new HashMap<String , ArrayList<String>>();
		//4 types of assertion values	
		ArrayList<HashMap<String,ArrayList<String[]>>> MutantAssertsValues=new ArrayList<HashMap<String,ArrayList<String[]>>>();
	    
		for(int i=0;i<4;i++){
	    	HashMap<String,ArrayList<String[]>> MutantAssertsValue=new HashMap<String,ArrayList<String[]>>();
	    	MutantAssertsValues.add(MutantAssertsValue);
	    }
	    //Text file
	    if(fileType.contains("Text"))
	    	MutantAssertions=ReadFiles.ReadText(path);
	    else if(fileType.contains("Zip"))
	    	MutantAssertions=ReadFiles.ReadZip(path);

	    List<String> MethodsCoveredbyF=(ArrayList)ParseInfor.get(0);        
	    for(String Muts:MutantAssertions.keySet()){
	    	String MethodDes="";
	    	String mutator="";
	    	String MutaIndex="";
	    	String lineNumber="";
	    	String mutatedMethod="";
	    	String mutatedClass="";
	    	
	    	String[] ms=Muts.split("&");
	    	
	    	MethodDes=ms[0].split("MutationDetails")[1];
	    	mutator=ms[1];
	    	MutaIndex=ms[2];
	    	lineNumber=ms[3];
	    	mutatedMethod=ms[4];
	    	mutatedClass=ms[5];
	    	
	    	
	    	/*String MethodDes= Muts.split("methodDesc=")[1].split("\\],")[0];

	    	String mutator=Muts.split("mutator=")[1].split("\\],")[0];

	    	String MutaIndex=Muts.split("indexes=\\[")[1].split("\\],")[0];
	           
	    	String lineNumber=Muts.split("lineNumber=")[1].split(",")[0];
	          
	    	String mutatedMethod=Muts.split("method=")[1].split(",")[0];
	          
	    	String mutatedClass=Muts.split("clazz=")[1].split(",")[0];*/
	    	
	    	
	    	
	    	String Method=mutatedClass+"."+mutatedMethod+MethodDes;
	    	String MutatedLine=mutatedClass+'.'+mutatedMethod+":"+lineNumber;
            String Mutant=Method+":"+lineNumber+':'+mutator+':'+MutaIndex+"+++++"+MutatedLine;
	    	
	    	String[] Testsin=Muts.split("testsInOrder=\\[")[1].split("\\)\\]\\]");
	    	String[] AllTestInorder=null;
	    	if(Testsin.length>0)
	    		AllTestInorder=Testsin[0].split(", ");
	    	ArrayList<String> Testinorder=new ArrayList<String>();
	    	if(AllTestInorder!=null){
	    		for(String test:AllTestInorder){
	    			if(!test.contains(RunMain.excludeTestClass)){
	    				int testindex=Integer.parseInt(test);
	    				Testinorder.add(RunMain.AllTests.get(testindex));
	    			} 
	    		}
	    	}
	    	if (RunMain.StatementsCoverdbyF.contains(MutatedLine)){     //Partial
	    		
	    		
			    
	            ArrayList<String[]> assertsValue0=new ArrayList<String[]>();
	            ArrayList<String[]> assertsValue1=new ArrayList<String[]>();
	            ArrayList<String[]> assertsValue2=new ArrayList<String[]>();
	            ArrayList<String[]> assertsValue3=new ArrayList<String[]>();
	        
	            List<String> AzeroFail=new ArrayList<String>();   //a0 assertion fail
	            if(MutantAssertions.get(Muts).size()>0){
	            	for(String TestAssertions:MutantAssertions.get(Muts)){   //each mutatant and its assertions
	            		String[] items=TestAssertions.split(":");
	            		String FA="";
	            		String TrueOrFalse="";
	            		String Message="";
	            		String Excetion="";
	            		String EMT="";
	            		if (TestAssertions.contains("[EXCEPTION]")&&TestAssertions.split("\\(").length>1){    //a0 assertion
	            			
	            			/*if(!RunMain.Project.contains(RunMain.ZipProject)){
	            				List<Object> exceptionInfor=ParseExceptions(TestAssertions,AzeroFail);
		            			FA=(String)exceptionInfor.get(4);
	            				TrueOrFalse=(String)exceptionInfor.get(0);
	            				Excetion=(String)exceptionInfor.get(1);
	            				Message=(String)exceptionInfor.get(2);
	            				EMT=(String)exceptionInfor.get(3);	
	            			}else{*/
	            				TrueOrFalse=TestAssertions.split("Type1=")[1].split(",")[0];
	            				
	            				Excetion=TestAssertions.split("Type2=")[1].split(",")[0];
	            				
	            				Message=TestAssertions.split("Type3=")[1].split(",")[0];
	            				
	            				EMT=TestAssertions.split("Type4=")[1].split(",")[0];
	            				
	            				FA=TestAssertions.split("\\(")[0].split(" ")[1]+":0000";
	            				
	            				AzeroFail.add(TestAssertions.split("\\(")[0].split(" ")[1]);
	            			//}
	            		

	            		}else {

	            				FA=TestAssertions.split(",")[0];
	            				if(TestAssertions.contains("T1"))
	            					TrueOrFalse=TestAssertions.split("T1=")[1].split(",")[0];
	            				if(TestAssertions.contains("T234")){
	            					String Value=TestAssertions.split("T234=")[1].split(",")[0];
	            					Excetion=Value;
	            					Message=Value;
	            					EMT=Value;
	            				}
	            				
	            			//}
	            			
	            		} 
	            		String[] FaValue0={FA,TrueOrFalse};
	            		String[] FaValue1={FA,Excetion};
	            		String[] FaValue2={FA,Message};
	            		String[] FaValue3={FA,EMT};
	            		assertsValue0.add(FaValue0);
	            		assertsValue1.add(FaValue1);
	            		assertsValue2.add(FaValue2);
	            		assertsValue3.add(FaValue3);
	            	}
	            }
	            if(Testinorder!=null){
	            	for(String t:Testinorder){    
	            		if(!AzeroFail.contains(t)){
	            			String Azero=t+":0000";
	            			String[] FaValue0={Azero,"true"};
	            			String[] FaValue1={Azero,"PASS"};
	            			String[] FaValue2={Azero,"PASS"};
	            			String[] FaValue3={Azero,"PASS"};
	            			assertsValue0.add(FaValue0);
	            			assertsValue1.add(FaValue1);
	            			assertsValue2.add(FaValue2);
	            			assertsValue3.add(FaValue3);
	            		}                               
	            	}
	            }
	            MutantAssertsValues.get(0).put(Mutant,assertsValue0); 
	            MutantAssertsValues.get(1).put(Mutant,assertsValue1);
	            MutantAssertsValues.get(2).put(Mutant,assertsValue2);
	            MutantAssertsValues.get(3).put(Mutant,assertsValue3);
	    	} // Partial    
	    	
	    	
	    }
	    List<Object> TraPTMutantParsed=new ArrayList<Object>();
	    TraPTMutantParsed.add(MutantAssertsValues);
	    return TraPTMutantParsed;       
	}
	public static List<Object> ParseExceptions(String TestAssertions,List<String> AzeroFail){
		
		
		String TestName=TestAssertions.split("\\(")[0].split(" ")[1];
		
		String FA=TestName+":0000";
		AzeroFail.add(TestName);
		
		int fistParenthe=TestAssertions.indexOf(") ");
		//String usefulInfor=TestAssertions.split("\\) ")[1];
		String usefulInfor=TestAssertions.substring(fistParenthe+2);
		
		//type and Message
		String Message=usefulInfor.split(" \\[STACKTRACE\\]")[0].split(usefulInfor.split(" ")[0]+" ")[1];
		
		String Traces="";
		if(TestAssertions.split("STACKTRACE\\] ").length>1){    //have some traces
			String[] traces=TestAssertions.split("STACKTRACE\\] ")[1].split(" ");
			for(String trace:traces){
				if(trace.contains(RunMain.StacktracePrefix)) 
					Traces=Traces+trace;                            
			} 
		}
		
		
		List<Object> exceptionInfor=new ArrayList<Object>();
		exceptionInfor.add(usefulInfor.split(" ")[0]); //TrueOrFalse
		exceptionInfor.add(Message.split(" ")[0]);		//Exception
		exceptionInfor.add(Message);					//Exception+Message
		exceptionInfor.add(Message+Traces);				//EMT
		exceptionInfor.add(FA);
		
		
		return exceptionInfor;
	}
	public static ArrayList<String> parseAssertions(String[] items){
		ArrayList<String> assertStrings=new ArrayList<String>();
		if(items.length==5){ 
			if(items[4].split(" ").length>3){
				String TestName=items[4].split("\\(")[0].split(" ")[1];		  
				String FA=TestName+":"+items[3]+":"+items[4].split(" ")[0];
				String TrueOrFalse=items[4].split(" ")[2];
				String Value=items[4].split(" ")[3];
				/*String Excetion=Value;
				String Message=Value;
				String EMT=Value;*/
				assertStrings.add(TrueOrFalse);
				assertStrings.add(Value);
				/*assertStrings.add(Message);
				assertStrings.add(EMT);*/
				assertStrings.add(FA);
			}
		}
		return assertStrings;
	}
	public static String parseMutants(String Muts){
		String MethodDes= Muts.split("methodDesc=")[1].split("\\],")[0];

    	String mutator=Muts.split("mutator=")[1].split("\\],")[0];

    	String MutaIndex=Muts.split("indexes=\\[")[1].split("\\],")[0];
           
    	String lineNumber=Muts.split("lineNumber=")[1].split(",")[0];
          
    	String mutatedMethod=Muts.split("method=")[1].split(",")[0];
          
    	String mutatedClass=Muts.split("clazz=")[1].split(",")[0];
		
		String useforMutants="MutationDetails"+MethodDes+"&"+mutator+"&"+MutaIndex+"&"+lineNumber+"&"+mutatedMethod+"&"+mutatedClass+"&";
		
		return useforMutants;
	}
}
