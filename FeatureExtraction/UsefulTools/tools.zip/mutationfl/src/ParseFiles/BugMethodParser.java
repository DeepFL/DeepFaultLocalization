package ParseFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class BugMethodParser {
	public static ArrayList<String> BugMethod(String path) throws IOException{
		BufferedReader BugM= new BufferedReader(new FileReader(path));
		String line = BugM.readLine();
		ArrayList<String> BugMethods=new ArrayList<String>();
		while (line != null) {
			if (line.contains("^^^^^^")) {
				String BM=line.substring(line.indexOf("^^^^^^") + 6).replace(":", ".");
				if(!BugMethods.contains(BM))
					BugMethods.add(BM);
			}
			line = BugM.readLine();
		}
		return BugMethods;
	}
}
