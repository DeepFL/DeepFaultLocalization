package ParseFiles;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import org.eclipse.jdt.core.IImportDeclaration;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.Document;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.compiler.IProblem;


import Main.RunMain;
import Techs.*;

public class SourceCodeParser{

public static void FailingMethod(String basedir,String filePath,String filename,String str,String Classprefix,List<String> FailingTests,HashMap<String,String> MethodandSourcecode,
								 HashMap<String,String> TestandSourcecode,HashMap<String,String> MethodandIden) throws Exception{
	
	ASTParser parser = ASTParser.newParser(AST.JLS8);
	
	
	parser.setResolveBindings(true);
	parser.setKind(ASTParser.K_COMPILATION_UNIT);
	parser.setBindingsRecovery(true);
	
	Map options = JavaCore.getOptions();
	parser.setCompilerOptions(options);
	
	parser.setUnitName(filename);
	
	String[] sources = { basedir }; 
	String[] classpath = {"/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar"};

	parser.setEnvironment(classpath, sources, new String[] { "UTF-8"}, true);
	
	
	parser.setSource(str.toCharArray());
	
	
	CompilationUnit astRoot = (CompilationUnit) parser.createAST(null);

	
    // iterate over all types
	for (int t = 0; t < astRoot.types().size(); t++) {	
		//Get Classs
		TypeDeclaration typeDecl=null;
		if(astRoot.types().get(t) instanceof TypeDeclaration ){
			typeDecl = (TypeDeclaration) astRoot.types().get(t);
			// iterate over all the methods
			for (MethodDeclaration methodDecl : typeDecl.getMethods()) {
				String MethodName="";
				if(methodDecl.getName()!=null&&methodDecl.getBody()!=null){
					MethodName=methodDecl.getName().toString();
					String fullMethodname=Classprefix+"."+MethodName;
					
					String MethodBody=methodDecl.getBody().toString();
					if(FailingTests.contains(fullMethodname)){
						TestandSourcecode.put(fullMethodname,MethodBody);
					}
					
					int starpos=astRoot.getLineNumber(methodDecl.getBody().getStartPosition());
					int length=astRoot.getLineNumber(methodDecl.getBody().getLength());
					for(int i=1;i<length+1;i++){
						int line=starpos+i;
						String MethodLine=Classprefix+":"+line;
						if(RunMain.LineandMethod.containsKey(MethodLine)){
							String MethodSig=RunMain.LineandMethod.get(MethodLine);
							if(!MethodandSourcecode.containsKey(MethodSig))
								MethodandSourcecode.put(MethodSig,MethodBody);
							else
								break;
						}	
					}
				}
			}
		
		}
	}
	
	GetIndentifiers(astRoot,Classprefix,MethodandIden);
	
}

public static void GetIndentifiers(CompilationUnit astRoot,String Classprefix,HashMap<String,String> MethodandIden){
	//MethodandIden:"Method1:varible1 varible2 varibleN"
    											                                           
	astRoot.accept(new ASTVisitor() {
		
		public boolean visit(MethodDeclaration md) {
			StringBuilder EachMethod=new StringBuilder();
			String MethodSig="";
			String MethodName=md.getName().toString();
			if(md.getName()!=null&&md.getBody()!=null){
				String fullMethodname=Classprefix+"."+MethodName;
				int starpos=astRoot.getLineNumber(md.getBody().getStartPosition());
				int length=astRoot.getLineNumber(md.getBody().getLength());
				for(int i=1;i<length+1;i++){
					int line=starpos+i;
					String MethodLine=Classprefix+":"+line;
					if(RunMain.LineandMethod.containsKey(MethodLine)){
						if(MethodSig==""){
							MethodSig=RunMain.LineandMethod.get(MethodLine);
							EachMethod.append(MethodSig+":");
							EachMethod.
							append("<ClassName></ClassName><VariableName></VariableName><MethodName></MethodName><Comments></Comments><allfeature></allfeature>");
						}   //all feature: class,variable,method,comment
						else
							break;
					}
				}
			}
			
	    	md.accept(new ASTVisitor() {
	    		public boolean visit(SimpleName SN) {                //variable
	    			if (SN.resolveBinding() instanceof IVariableBinding){
	    				if(EachMethod.toString().length()>0){
		    				int index=EachMethod.indexOf("</VariableName>");
		    				int indexall=EachMethod.indexOf("</allfeature>");
		    				EachMethod.insert(indexall," "+SN.toString());
		    				EachMethod.insert(index," "+SN.toString());
		    			}
	    			}
	    			if (SN.resolveBinding() instanceof IMethodBinding){    //Method
	    				if(!SN.toString().equals(md.getName().toString())){
	    					if(EachMethod.toString().length()>0){
	    						int index=EachMethod.indexOf("</MethodName>");
	    						int indexall=EachMethod.indexOf("</allfeature>");
			    				EachMethod.insert(indexall," "+SN.toString());
	    	    				EachMethod.insert(index," "+SN.toString());
	    	    			}
	    				}
	    			}
	    			if(SN.resolveBinding() instanceof ITypeBinding){    //Class
	    				if(EachMethod.toString().length()>0){
		    				int index=EachMethod.indexOf("</ClassName>");
		    				int indexall=EachMethod.indexOf("</allfeature>");
		    				EachMethod.insert(indexall," "+SN.toString());
		    				EachMethod.insert(index," "+SN.toString());
	    				}
	    			}
	    			return false;
	    		}
	    		public boolean visit(Javadoc jcomment){                   //comments
	    			if(EachMethod.toString().length()>0){
	    				String content=InformationR.splitCamelCase(jcomment.toString().replaceAll(InformationR.reg," "));
	    				int index=EachMethod.indexOf("</Comments>");
	    				int indexall=EachMethod.indexOf("</allfeature>");
	    				EachMethod.insert(indexall," "+content);
	    				EachMethod.insert(index," "+content);
    				}
	    			return false;
	    		}
	    	});
	    	if(EachMethod.toString().length()>0){
	    		String keyMethodSig=EachMethod.toString().split(":")[0];
	    		String keyMethInfors="";
	    		if(EachMethod.toString().split(":").length>1)
	    			keyMethInfors=EachMethod.toString().split(":")[1];
	    		MethodandIden.put(keyMethodSig,keyMethInfors);
	    	}
	    	return false;
	    	}
	});
	
	
}

public static void ParseFilesInDir(String basedir,File f,List<String> FailingTests,HashMap<String,String> MethodandSourcecode,
												HashMap<String,String> TestandSourcecode,HashMap<String,String> MethodandIden) throws Exception{
    
	if (f.isDirectory()) {
			File[] children = f.listFiles();
			for (File c : children) {
		      ParseFilesInDir(basedir,c,FailingTests,MethodandSourcecode,TestandSourcecode,MethodandIden);
			}
		}
		else if(f.getName().endsWith(".java")){
            String filePath=f.getAbsolutePath();

            String packprefix=""; //"org" or "coms
            if(filePath.contains("/org/"))
            	packprefix="org";
            else if(filePath.contains("/com/"))
            	packprefix="com";
            String Classprefix=packprefix+"."+filePath.split(packprefix+"/")[1].split("\\.java")[0].replace("/",".");
            
            FailingMethod(basedir,filePath,f.getName().toString(),readFileToString(filePath),Classprefix,FailingTests,MethodandSourcecode,TestandSourcecode,MethodandIden);
		}
}
public static String readFileToString(String filePath) throws IOException {
	StringBuilder fileData = new StringBuilder();
	BufferedReader reader = new BufferedReader(new FileReader(filePath));
	char[] buf = new char[10];
	int numRead = 0;
	while ((numRead = reader.read(buf)) != -1) {
		//System.out.println(numRead);
		String readData = String.valueOf(buf, 0, numRead);
		fileData.append(readData);
		buf = new char[1024];
	}

	reader.close();

	return  fileData.toString();	
}

	
}
