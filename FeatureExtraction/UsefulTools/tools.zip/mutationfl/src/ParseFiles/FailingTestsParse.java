package ParseFiles;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FailingTestsParse {
	private static int fp=0;   //number of failingtests
	public static void SetFp(int failingp){
		fp=failingp;
	}
	public static int getFp(){
		return fp;
	}
	public static List<String> GetFailingTests(String path) throws IOException{
		fp=0;
		BufferedReader br = new BufferedReader(new FileReader(path));
		String line2 = br.readLine();
		List<String> FT = new ArrayList<String>();
		while (line2 != null) {
			FT.add(line2.replace("::","."));
			line2 = br.readLine();
		}
		br.close();		
        fp=FT.size();
        return FT;
    }

}
