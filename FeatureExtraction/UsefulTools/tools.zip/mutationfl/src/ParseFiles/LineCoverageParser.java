package ParseFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import Main.RunMain;

public class LineCoverageParser {
	private static int fpAndpp=0;
	public static void SetfpAndpp(int number){
		fpAndpp=number;
	}
	public static int getfpAndpp(){
		return fpAndpp;
	}
	
	public static List<Object> ParseCoverage(String path, Map<String, String> LineandMethod,List<String>  FailingTests) throws IOException{ 
		fpAndpp=0;
		int TestCaseNumber=0;
		List<String> MethodsCoveredbyF = new ArrayList<String>();
	    List<String> StatementsCoveredbyF = new ArrayList<String>();
	    Map<String, Set<String>> TestCoverage = new HashMap<String, Set<String>>();//Test1->method1,method2...
	    Map<String, Set<String>> LineCoverage=new HashMap<String, Set<String>>();//line1->tests1,tests2...
		Map<String, Set<String>> MethodCoverage=new HashMap<String, Set<String>>();//Method1->test1,test2...
		ArrayList<String> AllTests=new ArrayList<String>();
		List<Object> UsefulInfor=new ArrayList<Object>();
		
		BufferedReader reader = new BufferedReader(new FileReader(path));
	    String line = reader.readLine();
	    while (line != null) {
	    	fpAndpp=fpAndpp+1;
	    	String[] items = line.split("\t");
	    	String test = items[0];
	    	if (items[0].contains("(")){
	    		test = items[0].substring(0, items[0].indexOf("("));
	    		if(!AllTests.contains(test))
	    			AllTests.add(test);
	    	
	    		Set<String> methods = new HashSet<String>();
	    		for (int i = 1; i < items.length; i++) {
	    			// System.out.println(items[i]);
	    			String[] itemsitems=items[i].split(":");
	    			String newitem=itemsitems[0]+"."+itemsitems[1]+":"+itemsitems[2];
	    			String Method=LineandMethod.get(newitem);
					  
	    			if(Method!=null){  
	    				if(!LineCoverage.containsKey(newitem)){
	    					Set<String> tests = new HashSet<String>();
	    					tests.add(test);                  
	    					LineCoverage.put(newitem,tests);
	    				}else
	    					LineCoverage.get(newitem).add(test);
	                
	    				if(!MethodCoverage.containsKey(Method)){
	    					Set<String> tests = new HashSet<String>();
	    					tests.add(test);                  
	    					MethodCoverage.put(Method,tests);
	    				}else
	    					MethodCoverage.get(Method).add(test);
	                  

	    				methods.add(Method);
	    				if (FailingTests.contains(test)){
	    					if (!MethodsCoveredbyF.contains(Method))
	    						MethodsCoveredbyF.add(Method);
	    				
	    					if (!StatementsCoveredbyF.contains(newitem))
	    						StatementsCoveredbyF.add(newitem);
	    				}
	    			}
	    		}
	    	
	    		TestCoverage.put(test,methods);
	    		}
			line = reader.readLine();
	    }
	    UsefulInfor.add(MethodsCoveredbyF);
		UsefulInfor.add(StatementsCoveredbyF);
		UsefulInfor.add(TestCoverage);
		UsefulInfor.add(LineCoverage);
		UsefulInfor.add(MethodCoverage);
		UsefulInfor.add(fpAndpp);
		UsefulInfor.add(AllTests);
		return UsefulInfor;
	}
}
