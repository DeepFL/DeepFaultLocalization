package ParseFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import Main.RunMain;

public class IRAllMethodsParser {
	public static Map<String, String> Parse(String Path) throws IOException{
		//Almost exactly same with AllMEthodsParser
		BufferedReader br = new BufferedReader(new FileReader(Path));
		Map<String, String> LineandMethod = new HashMap<String, String>();
		String line1 = br.readLine();
		while (line1 != null) {
			String[] items = line1.split(":");
			
			String Line=items[0] + ":" + items[2];
			String Method=items[0]+"."+items[1];
			
			LineandMethod.put(Line, Method);
			line1 = br.readLine();
		}
	       
		br.close();
		return LineandMethod;
   }

}
