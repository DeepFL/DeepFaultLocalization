package ParseFiles;

import java.util.zip.GZIPInputStream;

//import org.apache.commons.io.FileUtils;
//import org.apache.commons.io.LineIterator;

import java.io.*;
import java.util.*;
import Main.*;

public class ReadFiles {
	public static Map<String, ArrayList<String>> ReadText(String Path) throws IOException{
		Map<String, ArrayList<String>> MutantAssertions=new HashMap<String,ArrayList<String>>();
		BufferedReader reader = new BufferedReader(new FileReader(Path));
		//Scanner reader = new Scanner(new File(Path));
		String line = PreClean2(reader.readLine());
		//reader.useDelimiter("\n");
		//String line = reader.next();
		String Flag="";
		while(line!=null){
			if(line.contains("MutationDetails")){
				Flag=line;
				ArrayList<String> Assertions=new ArrayList<String>();
				MutantAssertions.put(Flag,Assertions);
			}else
				if(!line.contains(RunMain.excludeTestClass))
					MutantAssertions.get(Flag).add(line); 
			
			line=PreClean2(reader.readLine());;
		}
	
		return MutantAssertions;
	}
	//original read zip
	public static Map<String, ArrayList<String>> ReadZip(String Path) throws IOException{
		Map<String, ArrayList<String>> MutantAssertions=new HashMap<String , ArrayList<String>>();
		File folder = new File(Path);
		File[] listOfFiles = folder.listFiles();
		int count=0;
		for (int i = 0; i < listOfFiles.length; i++) {
			String filename=listOfFiles[i].getAbsolutePath();
			GZIPInputStream zip=null;
			FileInputStream fis=null;
			try{
				fis=new FileInputStream(filename);
				zip = new GZIPInputStream(fis);
			}catch(EOFException eof){}
			
			//BufferedReader reader =null;
			Scanner reader=null;
			try{
				//reader = new BufferedReader(new InputStreamReader(zip, "UTF-8"));
				reader = new Scanner(new InputStreamReader(zip, "UTF-8"));
				
				count++;
				reader.useDelimiter("\n");
				String line = PreClean2(read(reader));
				String Flag="";
				while(line!=null){
					if(line.contains("MutationDetails")){
						Flag=line;
						ArrayList<String> Assertions=new ArrayList<String>();
						MutantAssertions.put(Flag,Assertions);
					}
					else{
						MutantAssertions.get(Flag).add(line); 
					}
					
					line = PreClean2(read(reader));
				
				}
				line=null;
				zip.close();
				reader.close();
			}catch(Exception e){}
			fis.close();
		}
		return MutantAssertions;		
	}
	
	public static String read(Scanner reader) {
		String line;
		if (reader.hasNext())
			line = reader.next();
		else
			line = null;
		return line;
	}
	
	
	
	

	public static String PreClean(String line){
		StringBuilder lineafterclean=new StringBuilder();
		String[] items=line.split("testsInOrder=\\[");
		String[] Testsinorder=items[1].split(", ");
		lineafterclean.append(MutationParser.parseMutants(items[0])+"testsInOrder=[");
		for(String test:Testsinorder){
			String t=test.split("\\(")[0];
			if(RunMain.FailingTests.contains(t)){
				int index=Main.RunMain.AllTests.indexOf(t);
				
				lineafterclean.append(Integer.toString(index)+", ");
			}
		}
		lineafterclean.append(")]]");
		
		return lineafterclean.toString();
	}
	public static String PreClean2(String line){
		String cleanline=null;
		if(line==null)
			cleanline=null;
		else if(line.contains("MutationDetails")){
			cleanline=PreClean(line);
		}else if(line.contains("[EXCEPTION]")&&!line.contains(RunMain.excludeTestClass)){
			StringBuilder lineafterclean=new StringBuilder();
			
			String[] items=line.split("\\[STACK");
			lineafterclean.append(items[0]+"[STACKTRACE] ");
			if(line.split("STACKTRACE\\] ").length>1){
				String[] stacktraces=items[1].split(" ");
				for(int i=1;i<stacktraces.length;i++){
					if(stacktraces[i].contains(RunMain.StacktracePrefix))
						lineafterclean.append(stacktraces[i]+" ");	
				}
			}
			
			cleanline=NewException(lineafterclean.toString(),RunMain.AssertionValues);

		}
		else
			cleanline=NewAssertion(line,RunMain.AssertionValues);
		return cleanline;
	}
	public static String NewException(String Mutationassertion, ArrayList<HashMap<String, String>> AssertionValues){
		StringBuilder NewException=new StringBuilder();
		NewException.append(Mutationassertion.split(("\\) "))[0]+") ");

		List<String> AzeroFail=new ArrayList<String>();// no use in this case
		List<Object> exceptionInfor=MutationParser.ParseExceptions(Mutationassertion, AzeroFail);
		String FA=(String)exceptionInfor.get(4);
		for(int i=0;i<4;i++){
			int type=i+1;
			String originalvalue=AssertionValues.get(i).get(FA).replaceAll("\\s+"," ");
			String mutantv=((String)exceptionInfor.get(i)).replaceAll("\\s+"," ");
			if(originalvalue.equals(mutantv)){
				NewException.append("Type"+type+"=NOCHANGE,");
			}
			else
				NewException.append("Type"+type+"=CHANGED,");
		}
	
		
		return NewException.toString();
	}
	public static String NewAssertion(String Mutationassertion, ArrayList<HashMap<String, String>> AssertionValues){
		StringBuilder NewException=new StringBuilder();
		String[] items=Mutationassertion.split(":");
		ArrayList<String> assertStrings=MutationParser.parseAssertions(items);
		if(assertStrings.size()>0){
			String FA=assertStrings.get(2);
			NewException.append(FA+",");  //add FA
			if(AssertionValues.get(0).containsKey(FA)&&AssertionValues.get(1).containsKey(FA)){
				String originTF=AssertionValues.get(0).get(FA);
				String originValue=AssertionValues.get(1).get(FA);
				
				String TF=assertStrings.get(0);
				String Value=assertStrings.get(1);
				if(!originTF.equals(TF))
					NewException.append("T1=CHANGED,");
				else
					NewException.append("T1=NOCHANGE,");
					
				
				if(!originValue.equals(Value))
					NewException.append("T234=CHANGED,");
				else
					NewException.append("T234=NOCHANGE,");
			}
		}
		return NewException.toString();
		
	}
}
