package ParseFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import Main.RunMain;

public class MetricAllMethodsParser {
	public static Map<String, ArrayList<String>> Parse(String Path) throws IOException{
		//Almost exactly same with AllMethodsParser
		BufferedReader br = new BufferedReader(new FileReader(Path));
		Map<String, ArrayList<String>> MethodandLine = new HashMap<String, ArrayList<String>>();
		String line1 = br.readLine();
		while (line1 != null) {
			String[] items = line1.split(":");
			
			String Line=items[0] + ":" + items[2];
			String Method=items[0]+"."+items[1];
			if(!MethodandLine.containsKey(Method)){
				ArrayList<String> Lines=new ArrayList<String>();
				Lines.add(Line);
				MethodandLine.put(Method,Lines);
			}else
				MethodandLine.get(Method).add(Line);
			line1 = br.readLine();
		}
	       
		br.close();
		return MethodandLine;
   }

}
