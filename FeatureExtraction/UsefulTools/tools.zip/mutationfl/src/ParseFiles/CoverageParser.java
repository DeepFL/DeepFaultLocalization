/*
 * 
 * Parse coverage-test and coverage-assertion files
 * 
 * 
 */

package ParseFiles;
import java.io.*;
import java.util.*;
import Main.*;


public class CoverageParser {
	private static int fp=0;
	private static int pp=0;
	private static int fpAndpp=0;
	
	public static int getfp(){
		return fp;
	}
	public static int getpp(){
		return pp;
	}
	public static int getfpAndpp(){
		return fpAndpp;
	}
	public static void setfp(int a){
		fp=a;
	}
	public static void setpp(int b){
		pp=b;
	}
	
	public static List<Object> AssertCoverageParser(String path,List<String> FailingTests) throws IOException{
		setfp(0);
		setpp(0);
		List<Object> AssertionInfor=new ArrayList<Object>();
			
		//Assertions that each Test case includes
		Map<String, ArrayList<String>> TestToAssertions = new HashMap<String, ArrayList<String>>();
	        
		//4 kinds of Hashmap
		ArrayList<HashMap<String, String>> AssertionValues = new ArrayList<HashMap<String, String>>();
			
		//Each esseration with its values
		for(int i=0;i<4;i++){
			HashMap<String, String> AssertionValue=new HashMap<String,String>();
			AssertionValues.add(AssertionValue);
		}
		List<String> FailingAssertions=new ArrayList<String>();
		Set<String> PassAssertions=new HashSet<String>();
		
		BufferedReader reader = new BufferedReader(new FileReader(path));//AssertionCoverage File
		String line = reader.readLine();
		
		String Flag=""; //global test name
		Set<String> AllTests=new HashSet<String>();
		while (line != null&&!line.equals("")) {
			if(!line.contains("^^^^^^")){
				if(!line.contains(RunMain.excludeTestClass)){
				//ArrayList<String> Values=new ArrayList<String>();
				String Test="";  //Test Name
				String FA="";
				String TrueOrFalse="";
				String Value="";
				String usefulInfor="";
				String Traces="";
				String Message="";
				String Excetion="";
				String EMT="";  //Excetion+Message+Traces
				if(line.contains("(org")||line.contains("(com")){            
					if(line.contains("(org")){
						Test=line.split(("\\(org"))[0];
						FA=line.split("\\(org")[0]+":0000"; 
					}
					if(line.contains("(com")){
						Test=line.split(("\\(com"))[0];
						FA=line.split("\\(com")[0]+":0000";  
					}
					usefulInfor=line.split("\\) ")[1];
					TrueOrFalse=usefulInfor.split(" ")[0];
					if(line.contains("[STACKTRACE]")){
						List<Object> exceptionInfor=MutationParser.ParseExceptions("EXP "+line, new ArrayList<String>());
						
						Excetion=(String)exceptionInfor.get(1);
						Message=(String)exceptionInfor.get(2);
						EMT=(String)exceptionInfor.get(3);
					
					}else{
						Excetion="PASS";
						Message="PASS";
	                    EMT="PASS";
					}
					Flag=Test;
					AllTests.add(Flag);
				}else{                                //assertions
					String[] items=line.split(":"); 
	                if(items.length>1){
	                	FA=Flag+":"+items[3]+":"+items[4].split(" ")[0];
	                }
	                TrueOrFalse=line.split(" ")[1]; 
	                Value=line.split(" ")[2];
	                Excetion=Value;
	                Message=Value;
	                EMT=Value;
				} 
				AssertionValues.get(0).put(FA,TrueOrFalse);
				AssertionValues.get(1).put(FA,Excetion);
				AssertionValues.get(2).put(FA,Message);
				AssertionValues.get(3).put(FA,EMT);
				if(!TestToAssertions.containsKey(Flag)){
					ArrayList<String> FAs=new ArrayList<String>();
	                FAs.add(FA);
	                TestToAssertions.put(Flag,FAs);                    
				}else
					TestToAssertions.get(Flag).add(FA); 

				if(TrueOrFalse.contains("false")&&FailingTests.contains(Flag)&&!FailingAssertions.contains(FA)){
					FailingAssertions.add(FA);
					fp++;
				}else
					PassAssertions.add(FA);
			}
			}
			line=reader.readLine(); 
		}

	        pp=PassAssertions.size();
	        fpAndpp=fp+pp;
			//System.out.println("pp:"+pp);
	        //System.out.println("fp:"+fp);
	        //System.out.println(fpAndpp);
			AssertionInfor.add(FailingAssertions);
	        AssertionInfor.add(TestToAssertions);
			AssertionInfor.add(AssertionValues);
	        return AssertionInfor; 
	    }
	//Parse Linecoverage again after get coverage-test/coverage-asertion information
	public static ArrayList<Object>  AssertionCoverage(String path,List<Object> AssertionInfor,
													   Map<String, String> LineandMethod,List<String> FailingTest) throws IOException{  
        //Assertion Coverage: Each Line->Assert1,Assert2,...
		Map<String, Set<String>> LineCoverage=new HashMap<String, Set<String>>();
        //Each Method->Assert1,Assert2      
        Map<String, Set<String>> AssertionMethodCoverage=new HashMap<String, Set<String>>();

        
        BufferedReader reader = new BufferedReader(new FileReader(path));  //Linecoverage Path
        String line = reader.readLine();
        while (line != null) {
        	String[] items = line.split("\t");
        	String test = items[0];
        	if (items[0].contains("(")){
        		test = items[0].substring(0, items[0].indexOf("("));
        		Map<String, ArrayList<String>> TestToAssertions = (HashMap)AssertionInfor.get(1);
        		ArrayList<String> Assertions=TestToAssertions.get(test);   
  			
        		for (int i = 1; i < items.length; i++){
        			String[] itemsitems=items[i].split(":");
        			String newitem=itemsitems[0]+"."+itemsitems[1]+":"+itemsitems[2];
        			String Method=LineandMethod.get(newitem);
        			if(Method!=null&&Assertions!=null){   //remove testcase in the file "LineCoverage"
        				for(String Ass:Assertions){
        					if(!LineCoverage.containsKey(newitem)){
        						Set<String> tests = new HashSet<String>();
        						tests.add(Ass);     			   
        						LineCoverage.put(newitem,tests);
        					}else
  					      		LineCoverage.get(newitem).add(Ass); 
        				}
        			}
        		}
        	}
        	line=reader.readLine();
        } 
        for(String Line:LineCoverage.keySet()){
        	Set<String> Assertions=LineCoverage.get(Line);
        	String Method=LineandMethod.get(Line);
            if(!AssertionMethodCoverage.containsKey(Method))
            	AssertionMethodCoverage.put(Method,Assertions);
        } 
        ArrayList<Object> AssertCoverageInfor=new ArrayList<Object>();
        AssertCoverageInfor.add(LineCoverage);
        AssertCoverageInfor.add(AssertionMethodCoverage);
        return AssertCoverageInfor;
    }
}
