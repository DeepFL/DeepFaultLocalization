package ParseFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import Main.RunMain;

public class AllMethodsParser {
	public static Map<String, String> Parse(String Path) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader(Path));
		Map<String, String> LineandMethod = new HashMap<String, String>();
		String line1 = br.readLine();
		while (line1 != null) {
			String[] items = line1.split(":");
			String methName = items[1].substring(0, items[1].indexOf("("));
			String Line=items[0] + "." + methName + ":" + items[2];
			String Method=items[0]+"."+items[1];
			
			LineandMethod.put(items[0] + "." + methName + ":" + items[2], items[0]+"."+items[1]);
			line1 = br.readLine();
		}
	       
		br.close();
		return LineandMethod;
   }

}
