package ParseFiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import Main.RunMain;

public class FailureMessageParser {
public static HashMap<String,StringBuilder> ReadFailureMessage(String MessagePath) throws IOException{
		
		HashMap<String,StringBuilder> FailandMessage=new HashMap<String,StringBuilder>();
	
		BufferedReader br=new BufferedReader(new FileReader(MessagePath));
		String line=br.readLine();
		String flag="";
		while(line!=null){
			if(line.contains("---")){
				String test=line.split("--- ")[1].replaceAll("::", ".");
				FailandMessage.put(test,new StringBuilder());
				flag=test;
			}else{
				if(!line.contains("at "))     //falure type and message
					FailandMessage.get(flag).append(line.trim());
				else{                        //stacktraces
					if(line.contains(RunMain.StacktracePrefix)){
						String M=line.split("at ")[1].split("\\(")[0];
						String specific="";
						if(line.split("\\)")[0].split(":").length>1){
							String linenumber=line.split("\\)")[0].split(":")[1].trim();
							specific=M+":"+linenumber;
						}
						if(!RunMain.LineandMethod.containsKey(specific))
							FailandMessage.get(flag).append(line.trim().split("\\(")[0]+" ");
						else{
							String MethodSignature=RunMain.LineandMethod.get(specific);
							FailandMessage.get(flag).append(MethodSignature+" ");
						}
					}	
				}
			}
			line=br.readLine();
		}
		
	
		
	return FailandMessage;	
	}

}
