package Main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;

import ParseFiles.*;
import Techs.*;
import Utils.*;

public class RunMain {
	public static String excludeTestClass=
			"org.apache.commons.math3.genetics.UniformCrossoverTest";
	public static int TotalPF=0;
	public static int TotalFP=0;
	public static String Level="";
	//public static String Level="assert";
	public static String StacktracePrefix="";
	public static int fourheros=4;
	public static String Project;
	public static String rootDirPath;
	//public static String ZipProject="Closure"; //This setting is only for Closure
	
	public static void main(String[] args) throws Exception{
		String ID=args[1];
		Project=args[2];
		if(Project.contains("Lang")||Project.contains("Math"))
			StacktracePrefix="org.apache.commons";   //Lang and Math
		else if(Project.contains("Chart"))
			StacktracePrefix="org.jfree";      //Chart
		else if(Project.contains("Time"))
			StacktracePrefix="org.joda.time";        //Time
		else if(Project.contains("Closure"))
			StacktracePrefix="com.google.javascript";
		else if(Project.contains("Mockito")){
			StacktracePrefix="org.mockito";
			excludeTestClass="org.mockitousage.junitrunner.ModellingVerboseMockitoTest.org";
		}
			
		String Tech=args[0]; // "mutation" or "InformationR"
		
		rootDirPath = args[3];
		
		//mutation
		if(Tech.equals("mutation")){
			
			System.out.print(ID+" ");
			
			initialCommonData(ID,Project);
			
			
			String[] extypes={"Tarantula","Ochiai","Jaccard","Ample","RussellRao","Hamann","S��rensenDice","Dice",
					"Kulczynski1","Kulczynski2","SimpleMatching","Sokal","M1","M2","RogersTanimoto","Goodman",
					"Hamming","Euclid","Overlap","Anderberg","Ochiai2","Zoltar","Wong1","Wong2","Wong3","ER1a","ER1b",
					"ER5a","ER5b","ER5c","GP02","GP03","GP13","GP19","SBI","DStar"};
			
			ArrayList<String> types=new ArrayList<String>();
			for(String extype:extypes)
				types.add(extype);

			ArrayList<List<Integer>> SpectrumRank=RunSpectrum(types,ID,Project,"noAggre");
			
			types.add("Muse");
			
			ArrayList<ArrayList<List<Integer>>> UnknowRanks=RunUnknow(types,ID,Project);
			
			
		}else if(Tech.equals("InformationR")){
			
			initialCommonDataIR(ID,Project);
			
			HashMap<String,String> MethodandSourcecode=new HashMap<String,String>(); 
			HashMap<String,String> TestandSourcecode=new HashMap<String,String>();
			HashMap<String,String> MethodandIden=new HashMap<String,String>();
			
			String basedir=FilePath.ProjectsPath+Project+"/"+ID+"/src/";
			File f=new File(basedir);
			SourceCodeParser.ParseFilesInDir(basedir,f,RunMain.FailingTests,MethodandSourcecode,TestandSourcecode,MethodandIden);
			InformationR.WritetoIndriFile(FailandMessage,MethodandSourcecode,TestandSourcecode,Project,ID,MethodandIden);
		}else if(Tech.equals("mutator")){
			initialMutator(ID,Project);  //read and write mutator to files. once
		}else if (Tech.equals("MetricData")){//read Jhawk .xml and write to files,once
			initialCommonDataMetric(ID,Project);
			HashMap<String,ArrayList<String>> byteandmetrics=getMethodMetrics.bytcodMatch();
			
			BufferedWriter bw = null;
			File file = new File(FilePath.JhawkPath + "/" + Project + "/" + ID + ".txt");
		    FileWriter fw = new FileWriter(file,false);
			bw = new BufferedWriter(fw);
			for(String meth:byteandmetrics.keySet()){
				bw.write(meth+" ");
				for(String v:byteandmetrics.get(meth)){
					bw.write(v+",");
				}
				bw.write("\n");
			}
			bw.flush();
			bw.close();														
		}
	}
	public static void initialMutator(String ID,String Project) throws IOException{
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.ConditionalsBoundaryMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.IncrementsMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.InlineConstantMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.NegateConditionalsMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.NonVoidMethodCallMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.RemoveConditionalMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.ReturnValsMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.experimental.RemoveIncrementsMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.ArgumentPropagationMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.ConstructorCallMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.MathMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.VoidMethodCallMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.experimental.MemberVariableMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.experimental.RemoveSwitchMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.experimental.SwitchMutator");
		Allmutators.add("org.pitest.mutationtest.engine.gregor.mutators.InvertNegsMutator");
		
		
		LineandMethod=AllMethodsParser.Parse(FilePath.MethodPath+Project+"/"+ID+".txt"); 
		FailingTests=FailingTestsParse.GetFailingTests(FilePath.Failingpath+Project+"/"+ID+".txt");//Original failing tests
		CoverarageParseInformation=
		LineCoverageParser.ParseCoverage(FilePath.LineCoveragePath+Project+"/"+ID+".txt",
										 		LineandMethod, FailingTests);
		StatementsCoverdbyF =(ArrayList)CoverarageParseInformation.get(1);
		WriteAllMutator.CountMutant(FilePath.ProjectsPath+Project+"/"+ID+"/all-mutants.txt",
				FilePath.MutatorPath+Project+"/"+ID+".txt");  
		
		
	}
	

	public static void WriteSuspicous(NavigableMap<Double, Set<String>> FinalMap,String ID,String Project,
									  String Spectrumtype,String exceptionlevel,String Level) throws IOException{
		BufferedWriter bw = null;
		File file = new File(FilePath.ResutPath+"/SpectrumandMutation/" + Project + "/" + ID + "/" + Spectrumtype+exceptionlevel+".txt");
	    FileWriter fw = new FileWriter(file,false);
		bw = new BufferedWriter(fw);
		for(Double v:FinalMap.keySet()){
			Set<String> methods=FinalMap.get(v);
			for(String m:methods){
				bw.write(m+" "+ Double.toString(v));
				bw.write("\n");
			}
		}
		bw.flush();
		bw.close();
	}
	

	public static ArrayList<List<Integer>> RunSpectrum(ArrayList<String> types,String ID,String Project,String aggre) 
														throws IOException{
		ArrayList<List<Integer>> Ranks=new ArrayList<List<Integer>>();
		for(String type:types){
			Map<String, Double> Susvalue=null;
			if(aggre=="noAggre"){
				Susvalue=(HashMap)(Spectrum.SuspiciousValue(MethodCoverage,FailingTests,TestCaseNumber,type));
			}else if(aggre=="Aggre"){
				Map<String, Double> tempSusvalue=(HashMap)(Spectrum.SuspiciousValue(LineCoverage,FailingTests,TestCaseNumber,type));
				Susvalue=Spectrum.getNewSus(tempSusvalue,LineandMethod);
			}else{
				System.out.println("parameter error");
			}
			List<Integer> ranks=RankBySuspicious.RankMethod(Susvalue, BugMethods, MethodsCoveredbyF,ID,Project,type,"",Level);
			Ranks.add(ranks);
		}
		
		return Ranks;
	}
	
	public static ArrayList<ArrayList<List<Integer>>> RunUnknow(ArrayList<String> types,String ID,String Project) throws IOException{
		//4 types
		ArrayList<ArrayList<List<Integer>>> UnknowResults=new ArrayList<ArrayList<List<Integer>>>();
		for(int i=0;i<fourheros;i++){
			int ii=i+1;
			String exceptiontype="type"+ii;
			Map <String,Set<String>> MutantKillbyAsserts=Unknow.UnknowKilledMutant(MutantAssertsValues.get(i), AssertionValues.get(i),
														CoverarageParseInformation,FailingAssertion);
			ArrayList<List<Integer>> unknowresult=Unknow.UnknowRank(MutantKillbyAsserts,AssertNumber, FailingAssertion, BugMethods, MethodsCoveredbyF, 
															types,ID,Project,exceptiontype,Level);
			UnknowResults.add(unknowresult);	
		}
		return UnknowResults;
	}
	public static void initialCommonData(String ID,String Project) throws IOException{
		LineandMethod=AllMethodsParser.Parse(FilePath.MethodPath+Project+"/"+ID+".txt"); 
		BugMethods=BugMethodParser.BugMethod(FilePath.Bugpath+Project+"/"+ID+".txt");
		FailingTests=FailingTestsParse.GetFailingTests(FilePath.Failingpath+Project+"/"+ID+".txt");//Original failing tests
		CoverarageParseInformation=
		LineCoverageParser.ParseCoverage(FilePath.LineCoveragePath+Project+"/"+ID+".txt",
										 		LineandMethod, FailingTests);
		MethodsCoveredbyF=(ArrayList)CoverarageParseInformation.get(0);
		MethodCoverage =(Map) CoverarageParseInformation.get(4);// each method with its all test cases
        LineCoverage =(Map)CoverarageParseInformation.get(3);
        TestCo =(Map)CoverarageParseInformation.get(2);
        StatementsCoverdbyF =(ArrayList)CoverarageParseInformation.get(1);
        TestCaseNumber=(Integer)CoverarageParseInformation.get(5);
        
        AllTests=(ArrayList)CoverarageParseInformation.get(6);
        //FailandMessage=FailureMessageParser.ReadFailureMessage(FilePath.FailMessage+"/"+Project+"/trigger_tests/"+ID);
        
        
        
        CoverageInfor = CoverageParser.AssertCoverageParser(FilePath.MutationData + Project + "/coverage-test/"+ID+".txt",FailingTests);
        FailingAssertion=(ArrayList)CoverageInfor.get(0);
        AssertionValues = (ArrayList)CoverageInfor.get(2);    //original values of assert
        AssertCoverageInfor=CoverageParser.AssertionCoverage(FilePath.LineCoveragePath+Project+"/"+ID+".txt",CoverageInfor,
        																   LineandMethod,FailingTests);
        AssertCoverage=(HashMap)AssertCoverageInfor.get(0);
        
        AssertNumber=CoverageParser.getfpAndpp();
        
        if(Project.contains("Time")){
        	MutationParser.fileType="Zip";
        	MutatationInfor=MutationParser.AssertParser(FilePath.MutationData+Project+"/"+ID+"/mutation-test/", AssertCoverage, CoverarageParseInformation, FailingTests);
        }
        else if(Project.contains("Closure")){
        	MutationParser.fileType="Zip";
        	MutatationInfor=MutationParser.AssertParser("/home/xia/Xia/PITmutationData/"+Project+"/"+ID+"/mutation-test/", AssertCoverage, CoverarageParseInformation, FailingTests);;
        }
        else{
        	MutationParser.fileType="Text";
        	MutatationInfor=MutationParser.AssertParser(FilePath.MutationData+Project+"/mutation-test/"+ID+".txt", 
        			AssertCoverage, CoverarageParseInformation, FailingTests);
        }
        
       
        MutantAssertsValues=(ArrayList)MutatationInfor.get(0);
        	
     
        
	}
	public static void initialCommonDataIR(String ID,String Project) throws IOException{
		LineandMethod=IRAllMethodsParser.Parse(FilePath.MethodPath+Project+"/"+ID+".txt"); 
		FailingTests=FailingTestsParse.GetFailingTests(FilePath.Failingpath+Project+"/"+ID+".txt");
		FailandMessage=FailureMessageParser.ReadFailureMessage(FilePath.FailMessage+"/"+Project+"/trigger_tests/"+ID);
	}
	public static void initialCommonDataMetric(String ID,String Project) throws IOException{
		Methodandmetricvalues=XmlParser.ParseXML(FilePath.MetricXMLfile+"/"+Project+"/"+ID+".xml","Method");
		
		
		LineandMethod=AllMethodsParser.Parse(FilePath.MethodPath+Project+"/"+ID+".txt"); 
		MethodandLine=MetricAllMethodsParser.Parse(FilePath.MethodPath+Project+"/"+ID+".txt"); 
		FailingTests=FailingTestsParse.GetFailingTests(FilePath.Failingpath+Project+"/"+ID+".txt");
		CoverarageParseInformation=
				LineCoverageParser.ParseCoverage(FilePath.LineCoveragePath+Project+"/"+ID+".txt",
												 		LineandMethod, FailingTests);
		MethodsCoveredbyF=(ArrayList)CoverarageParseInformation.get(0);
	}
	


	public static Map<String, String> LineandMethod=null;
	public static Map<String, ArrayList<String>> MethodandLine=null;
	public static ArrayList<String> BugMethods=null;
	public static List<String> FailingTests=null;
	public static List<Object> CoverarageParseInformation=null;  //LineCoverageinformation
	public static ArrayList<String> MethodsCoveredbyF=null;
	public static Map<String, Set<String>> MethodCoverage=null;
	public static Map<String, Set<String>> LineCoverage=null;
	public static Map<String, Set<String>> TestCo=null;
	public static ArrayList<String> AllTests=null;
	public static ArrayList<String> StatementsCoverdbyF=null; 
	public static int TestCaseNumber=0;
	public static List<Object> CoverageInfor=null; //coverage-assert,coverage-test
	public static List<String> FailingAssertion=null;
	public static ArrayList<Object> AssertCoverageInfor=null;
	public static Map<String, Set<String>> AssertCoverage=null;
	public static int AssertNumber;
	public static List<Object> MutatationInfor=null; 
	public static ArrayList<HashMap<String,ArrayList<String[]>>> MutantAssertsValues=null;
	public static ArrayList<HashMap<String, String>> AssertionValues=null;
	public static HashMap<String,StringBuilder> FailandMessage=null;   //From defects4j
	
	public static HashMap<String,int[]> MethodandMutator=null;
	
	public static ArrayList<String> Allmutators=new ArrayList<String>();  //16 mutators
	//From Metrics xml
	public static HashMap<String,String> Methodandmetricvalues=null;
	
}
