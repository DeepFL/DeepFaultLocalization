package Techs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.*;

import Main.RunMain;

public class Spectrum {
	public static Map<String, Double> SuspiciousValue(Map<String, Set<String>> MethodCoverage,List<String> FailingTests,int TestCaseNumber,String type){
		Map<String, Double> SuspiciousValues=new HashMap<String, Double>();
		double PassingTestsSize=TestCaseNumber-FailingTests.size();
		double totalef=0.0;
		for(String method:MethodCoverage.keySet()){ 
			double ef=0.0;
	        double nf=0.0;
	        double ep=0.0;
	        double np=0.0;
			double value=0.0;
	        for(String test:MethodCoverage.get(method)){
	        	if(FailingTests.contains(test))
	        		ef++;
	        	else
	        		ep++; 
	        }
	        nf=FailingTests.size()-ef;
	        np=TestCaseNumber-nf-ef-ep;
	        
	        if(type.equals("Muse")){
	        	if (ep==0.0)
	        		value=ef;
	        	else
	        		value=ef-ep*RunMain.TotalFP/RunMain.TotalPF;
	        }
	        else if(type.equals("Method-OP"))
            	value=ef-ep/(ep+np+1);
	        else if(type.equals("Ample"))
	        	value=Math.abs(ef/(ef+nf)-ep/(ep+np));
	        else if(type.equals("Hamann"))
	        	value=(ef+np-ep-nf)/(ef+ep+nf+np);
	        else if(type.equals("SimpleMatching"))
	        	value=(ef+np)/(ef+ep+nf+np);
	        else if(type.equals("Sokal"))
	        	value=(2*ef+2*np)/(2*ef+2*np+nf+ep);
	        else if(type.equals("M1"))
	        	value=(ef+np)/(nf+ep);
	        else if(type.equals("RogersTanimoto"))
	        	value=(ef+np)/(ef+np+2*nf+2*ep);
	        else if(type.equals("Goodman"))
	        	value=(2*ef-nf-ep)/(2*ef+nf+ep);
	        else if(type.equals("Hamming"))
	        	value=ef+np;
	        else if(type.equals("Euclid"))
	        	value=Math.sqrt(ef+np);
	        else if(type.equals("Wong2"))
	        	value=ef-ep;
	        else if(type.equals("Wong3")){
	        	double h=0.0;
	        	if(ep<=2)
	        		h=ep;
	        	else if(ep>2&&ep<=10)
	        		h=2+0.1*(ep-2);
	        	else if(ep>10)
	        		h=2.8+0.01*(ep-10);
	        	value=ef-h; 	
	        }
	        else if(type.equals("ER1a")){
	        	if(ef<FailingTests.size())
	        		value=-1;
	        	else if(ef==FailingTests.size())
	        		value=PassingTestsSize-ep;
	        }
	        else if(type.equals("ER1b"))
            	value=ef-ep/(ep+np+1);
	        else if(type.equals("ER5c")){
	        	if(ef<FailingTests.size())
	        		value=0;
	        	if(ef==FailingTests.size())
	        		value=1;
	        }
	        else if(type.equals("GP02"))
	        	value=2*(ef+Math.sqrt(PassingTestsSize))+Math.sqrt(ep);
	        else if(type.equals("GP03"))
	        	value=Math.sqrt(Math.abs(ef*ef-Math.sqrt(ep)));
	        
	        
	       //-------------------------- 	
	        
	        	
	        
	        if(ef==0.0)
	        	value=0.0;
	        else{
	        	if(type.equals("SBI"))
	        		value=(double)ef/(ef+ep);
	            else if(type.equals("Purified"))
	            	value=(double)ef/(ef+nf);
	            else if(type.equals("Ochiai"))
	            	value=(double)ef/Math.sqrt((ef+nf)*(ef+ep));
	            else if(type.equals("Jaccard"))
	            	value=(double)ef/(ef+nf+ep);
	            else if(type.equals("Tarantula"))
	            	value=((double)ef/(ef+nf))/(ef/(ef+nf)+ep/(ep+np));
	            else if(type.equals("Ochiai2"))
	            	value=(double)ef*np/Math.sqrt((ef+ep)*(np+nf)*(ef+nf)*(ep+np));
	            else if(type.equals("Kulczynski2"))
	            	value=0.5*((double)ef/(ef+nf)+(double)ef/(ef+ep));
	       	    else if(type.equals("Method-B"))
	       	    	value=(double)ef/(ef+ep);
	            else if(type.equals("Method-O")){
	            	if(nf>0)
	            		value=-1;
	            	else
	            		value=np;
	            }
	            
	            else if(type.equals("DStar"))
	            	value=ef*ef/(nf+ep);
	            else if(type.equals("RussellRao"))
	            	value=ef/(ef+ep+nf+np);
	            else if(type.equals("S��rensenDice"))
	            	value=2*ef/(2*ef+ep+nf);
	            else if(type.equals("Dice"))
	            	value=2*ef/(ef+ep+nf);
	            else if(type.equals("Kulczynski1"))
	            	value=ef/(nf+ep);
	            else if(type.equals("M2"))
	            	value=ef/(ef+np+2*nf+2*ep);
	            else if(type.equals("Overlap")){
	            	double min=0.0;
	            	ArrayList<Double> vs=new ArrayList<Double>();
	            	vs.add(ef);
	            	vs.add(ep);
	            	vs.add(nf);
	            	min=Collections.min(vs);
	            	value=ef/min;
	            }
	            else if(type.equals("Anderberg"))
	            	value=ef/(ef+2*ep+2*nf);
	            else if(type.equals("Zoltar"))
	            	value=ef/(ef+ep+nf+10000*nf*ep/ef);
	            else if(type.equals("Wong1"))
	            	value=ef;
	            else if(type.equals("ER5a"))
	            	value=ef;
	            else if(type.equals("ER5b"))
	            	value=ef/(ef+nf+ep+np);
	            else if(type.equals("GP13"))
	            	value=ef*(1+1/(2*ep+ef));
	            else if(type.equals("GP19"))
	            	value=ef*Math.sqrt(Math.abs(ep-ef+FailingTests.size()-PassingTestsSize));
	        }
	        totalef=ef+totalef;
			  
	        SuspiciousValues.put(method,value);
		
	       /* if(method.contains("org.apache.commons.lang3.math.NumberUtils.createNumber")){
	        	System.out.println(method);
	            System.out.println("ef:"+ef+" ep:"+ep+" nf:"+nf+" np:"+np);
	            System.out.println(value);
	        }*/
		}
		
		return SuspiciousValues;
	}
	public static Map<String, Double> getNewSus(Map<String, Double> tempSusvalue,Map<String, String> LineandMethod){
		Map<String, Double> SuspiciousValues=new HashMap<String,Double>();
		for(String line:tempSusvalue.keySet()){
			String method=LineandMethod.get(line);
			if(!SuspiciousValues.containsKey(method)){
				SuspiciousValues.put(method,tempSusvalue.get(line));
			}else{
				double newv=tempSusvalue.get(line);
				double oldv=SuspiciousValues.get(method);
				if(newv>oldv){
					SuspiciousValues.put(method,newv);
				}
			}
		}
		return SuspiciousValues;
		
	}
}
