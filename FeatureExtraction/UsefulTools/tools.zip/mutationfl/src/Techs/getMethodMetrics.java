package Techs;
import java.util.*;

import Main.RunMain;
import ParseFiles.XmlParser;
public class getMethodMetrics {
	
	
	/*Metric Conversion:(1)primi type: int,Chart...--->I 
	 * 					(2)arguments: use references class
	 * 
	 *SusMethods Conversion: Inner class of return values
	 * 
	 * 
	 * 
	 * 
	 * 
	 */

	public static HashMap<String,ArrayList<String>> bytcodMatch(){
		//Generate
		HashMap<String,String> primiMap=byteMap();
		//methodName(bytecode)-->(metricvalue1,metricvalue2...) Final
		HashMap<String,ArrayList<String>> ByteMethodandMetrics=new HashMap<String,ArrayList<String>>(); 
		//Convert Metric side first
		HashMap<String,ArrayList<String>> MetricMethodArgs=new HashMap<String,ArrayList<String>>(); //name+args is unique 
		
		ArrayList<String> MetricOnlyMethodName=new ArrayList<String>(); //only package.class.methodname
		for(String methNameandArgs:RunMain.Methodandmetricvalues.keySet()){
			String byteCodeMethod1=CoverttoByte(methNameandArgs,primiMap,"withInnerClass"); //keep inner class
			String byteCodeMethod2=CoverttoByte(methNameandArgs,primiMap,"noInnerClass"); //remove inner class
			
			String MetricValues=RunMain.Methodandmetricvalues.get(methNameandArgs);
			ArrayList<String> Metrics=ConvertMetrivalues(MetricValues);   //convert metric values
			String byteMethArgs1=byteCodeMethod1.split("\\)")[0]+")";
			String byteMethArgs2=byteCodeMethod2.split("\\)")[0]+")";
			MetricMethodArgs.put(byteMethArgs1,Metrics); //format from metric.xml, almost same as bytecode 
			MetricMethodArgs.put(byteMethArgs2,Metrics);
			
			MetricOnlyMethodName.add(byteCodeMethod1.split("\\(")[0]);
			
		}
	
	
		ArrayList<String> newsusMethods=new ArrayList<String>();  //new susMethods( filter the methods not in metric.xml)
		for(String sus:RunMain.MethodsCoveredbyF){
			String byteOnlyMethodName=sus.split("\\(")[0];
			if(MetricOnlyMethodName.contains(byteOnlyMethodName)){
				newsusMethods.add(sus);
			}
			String susMethodandArgs=sus.split("\\)")[0]+")";  //name+arguments
			String newString="";
			if(MetricMethodArgs.containsKey(susMethodandArgs)){
				ByteMethodandMetrics.put(sus, MetricMethodArgs.get(susMethodandArgs));
			}else{                 //deal with sus methods not match with Metric
				newString=ForInner(sus,"removeDollar");  // special case:bytecode: package.class$innerclass  metric:    pacakge.innerClass  
				
				if(MetricMethodArgs.containsKey(newString))
					ByteMethodandMetrics.put(sus, MetricMethodArgs.get(newString));
				else{
					newString=ForInner(sus,"replaceDollar");  // special case:bytecode: package.class$innerclass   
					if(MetricMethodArgs.containsKey(newString))
						ByteMethodandMetrics.put(sus, MetricMethodArgs.get(newString));
					else{
						newString=ForInner(sus,"removePackage");  // special case  
						if(MetricMethodArgs.containsKey(newString))
							ByteMethodandMetrics.put(sus, MetricMethodArgs.get(newString));
						else{
							newString=ForInner(sus,"Onlyclass");  // special case  
							if(MetricMethodArgs.containsKey(newString))
								ByteMethodandMetrics.put(sus, MetricMethodArgs.get(newString));
						}
					}
				}
			}
		}
		
			
		Test(newsusMethods,ByteMethodandMetrics);
		return ByteMethodandMetrics;
	}

	public static String ForInner(String SusMethod,String diffCase){
		String pattern="\\$\\d+";  //$1.method
		String mName=SusMethod.split("\\(")[0];
		String newmName="";
		if(!mName.contains("$")){
			newmName=mName;
		}else{
			newmName=mName.replaceAll(pattern, "");
		}
		String[] mArgs=SusMethod.split("\\(")[1].split("\\)")[0].split(";");
		String NewArgs1=processClass(mArgs,diffCase);
		String NewArgs="";
		
		if(mName.contains("$")&&mName.contains("<init>")){    //init method of inner class
			String packageandclass=mName.split("\\$")[0];
			String firtarg=NewArgs1.split(";")[0];
			String compareclass="L"+packageandclass.replaceAll("\\.","/");
			if(compareclass.equals(firtarg)){
				int firstcolon=NewArgs1.indexOf(";");
				NewArgs=NewArgs1.substring(firstcolon+1,NewArgs1.length());
			}else
				NewArgs=NewArgs1;
		}else
			NewArgs=NewArgs1;
		
		String MetricMethod=newmName+"("+NewArgs+")";
		
		return MetricMethod;
	}
	public static String processClass(String[] argsOrreturns,String diffCase){
		StringBuilder NewArgs=new StringBuilder();
		for(String arg:argsOrreturns){
			if(!arg.contains("/")&&!arg.contains("$"))
				NewArgs.append(arg);
			else if(arg.contains("/")){
				if(!arg.contains("$")){
					if(diffCase.equals("Onlyclass")){//package/class--> class
						NewArgs.append("L");
						int lastslash=arg.lastIndexOf("/");
						NewArgs.append(arg.substring(lastslash+1,arg.length()));
						NewArgs.append(";");
					}else
						NewArgs.append(arg+";");
				}else{       
					if(diffCase.equals("removeDollar")){        //  package/class$innerclass--> package/innerclass
						int lastSlashIndex=arg.lastIndexOf("/");
						int lastDollarIndex=arg.indexOf("$");
						NewArgs.append(arg.substring(0,lastSlashIndex+1));
						NewArgs.append(arg.substring(lastDollarIndex+1,arg.length()));
						NewArgs.append(";");
						
					}else if(diffCase.equals("replaceDollar")){       // package/class$innerclass-->package/class/innerclass
						NewArgs.append(arg.replaceAll("\\$","/"));
						NewArgs.append(";");
					}else if(diffCase.equals("removePackage")){ 		// package/class$innerclass-->class/innerclass
						NewArgs.append(arg.split("L")[0]);
						NewArgs.append("L");
						int lastslash=arg.lastIndexOf("/");
						NewArgs.append(arg.substring(lastslash+1,arg.length()).replaceAll("\\$","/"));
						NewArgs.append(";");
						
						
					}
				}
			}
		}
		return NewArgs.toString();
		
	}
	public static void Test(ArrayList<String> MethodsCoveredbyF,
			HashMap<String,ArrayList<String>> ByteMethodandMetrics){
		ArrayList<String> keys=new ArrayList<String>();
		for(String key:ByteMethodandMetrics.keySet())
			keys.add(key);
		String Macter=".*\\d+\\.<init>.*";
		for(String f:MethodsCoveredbyF)
			if(!keys.contains(f)&&!f.contains("access$")&&!f.matches(Macter)&&RunMain.MethodandLine.get(f).size()>1)
				System.out.println(f);
	}
	
	public static String CoverttoByte(String methNameandArgs,HashMap<String,String> primiMap,String IfInner){
		StringBuilder MethodByte=new StringBuilder();
		String[] items=methNameandArgs.split("\\+\\+\\+");
		if(IfInner.equals("withInnerClass"))    //keep innerclass
			MethodByte.append(items[0]); 
		else{
			if(items[0].contains("$")){

				int lastDollar=items[0].lastIndexOf("$");
				int lastdot=items[0].lastIndexOf(".");
				String newitem=items[0].substring(0, lastDollar)+items[0].substring(lastdot,items[0].length());
				MethodByte.append(newitem);

			}else
				MethodByte.append(items[0]);
		}
		if(methNameandArgs.contains("++++++")) //No arguments
			MethodByte.append("()");
		else{
			MethodByte.append("(");
			String[] paras=items[1].split(" ");    //Aruguments split by " "
			for(String v:paras){               //loop all arguments
				String NewV=MatchSignature(v,primiMap);
				MethodByte.append(NewV);
			}
			MethodByte.append(")");
		}
				
		String ReturnValues=items[items.length-1];
		String newReturnV=MatchSignature(ReturnValues,primiMap);
		MethodByte.append(newReturnV);
		
		return MethodByte.toString();
	}
	public static ArrayList<String> ConvertMetrivalues(String MetricValues){
		String[] vs=MetricValues.split(" ");
		ArrayList<String> values=new ArrayList<String>();
		for(String v:vs){
			values.add(v.split(":")[1]);
		}
		return values;
	}
	
	//parse single argument
	public static String MatchSignature(String para1,HashMap<String,String> primiMap){
		StringBuilder newPara=new StringBuilder(); 
		String para=para1.replaceAll("\\.\\.\\.","[]");
		String[] items=para.split("\\[");
		String cla=items[0];  // only type
		String newcla=process(cla,primiMap);
		if(items.length==1){
			newPara.append(newcla);
			return newPara.toString();
		}else if(items.length==2)  {//one-way array
			newPara.append("[");
			newPara.append(newcla);
			return newPara.toString();
		}else if(items.length==3){ //two-way array
			newPara.append("[[");
			newPara.append(newcla);
			return newPara.toString();
		}else
			return para;
			
	}
	public static String process(String clas,HashMap<String,String> primiMap){

		if(primiMap.containsKey(clas)){   //primitive types: int,Lang,chart,...
			return primiMap.get(clas);
		}else if(clas.equals("L")||clas.equals("M")||clas.equals("R")||clas.equals("T")||clas.equals("V")||clas.equals("K")||
					clas.equals("N")||clas.equals("E")){
			return "Ljava/lang/Object;";
		}else if(clas.equals("F")){
			return "Ljava/text/Format;";
		}else if(clas.equals("void")){
			return "V";
		}else if(clas.equals("StringBuilder")){
			return "Ljava/lang/StringBuilder;";
		}else if(clas.equals("Iterable")){
			return "Ljava/lang/Iterable;";
		}else if(clas.equals("Appendable")){
			return "Ljava/lang/Appendable;";
		}else if(clas.equals("SourceMap")){
			return "Lcom/google/javascript/jscomp/SourceMap;";
		}
		
		else{
			String newclas=clas.replaceAll("\\.","/");
			if(newclas.contains("jscomp/graph/Node"))      //Special case for Closure
				newclas=newclas.replaceAll("jscomp/graph/Node","rhino/Node");
			return "L"+newclas+";";
		}
	}
	public static HashMap<String,String> byteMap(){    //add some special case
		HashMap<String,String> primiMap=new HashMap<String,String>();
		//primitive Match
		primiMap.put("int","I");
		primiMap.put("float","F");
		primiMap.put("long","J");
		primiMap.put("double","D");
		primiMap.put("short","S");
		primiMap.put("byte","B");
		primiMap.put("char","C");
		primiMap.put("boolean","Z");
		primiMap.put("Object","Ljava/lang/Object;");
		primiMap.put("java/lang/reflect/ParameterizedType","com/google/javascript/rhino/jstype/ParameterizedType");
		return primiMap;
	}

}
