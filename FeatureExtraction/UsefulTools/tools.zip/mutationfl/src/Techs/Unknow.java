package Techs;

import java.io.*;
import java.util.*;

import Main.RunMain;
import Utils.*;

public class Unknow {
	public static Map<String,Set<String>> UnknowKilledMutant(HashMap<String,ArrayList<String[]>> MutantAssertsValue,
															HashMap<String, String> AssertionValues,
															List<Object> ParseInfor,List<String> FT) throws IOException{
		Map<String,Set<String>> MutantKillbyAsserts=new HashMap <String,Set<String>>();//mutant with its 
		                                                                               //killing asserts
		
		List<String> StatementsCoveredbyF=(ArrayList)ParseInfor.get(1);
		int TotalChanged=0;
		for(String Mutant:MutantAssertsValue.keySet()){
			String MutatedLine=Mutant.split("\\+\\+\\+\\+\\+")[1];
			ArrayList<String[]> assertsvalue=MutantAssertsValue.get(Mutant);

			String[] items=Mutant.split("\\+\\+\\+\\+\\+")[0].split(":");
			String MethodandMutant=items[0]+":"+items[2]+":"+items[3];
			
		    for(String[] avalue:assertsvalue){
		    	String Assert=avalue[0];
		    	String value=avalue[1];
		    	if(AssertionValues.containsKey(Assert)){
		    		String originvalue=AssertionValues.get(Assert);
		    		if(value.contains("CHANGED")||(!value.contains("CHANGE")&&!value.equals(originvalue))){
		    		
		    			TotalChanged++;
		    			if(!MutantKillbyAsserts.containsKey(MethodandMutant)){
		    			
		    				Set<String> killingAsserts=new HashSet<String>();
		    				killingAsserts.add(Assert);
		    				MutantKillbyAsserts.put(MethodandMutant,killingAsserts);
		    			}else
		    				MutantKillbyAsserts.get(MethodandMutant).add(Assert); 
		    			
		    			if(FT.contains(Assert)){
							//if(StatementsCoveredbyF.contains(MutatedLine)){ //Actually, this filter is not required.
								RunMain.TotalFP++;
							//}
								
						}else
							RunMain.TotalPF++;
		    		}  
		    	}	
		    }
		}
		return MutantKillbyAsserts;
	}
	public static ArrayList<List<Integer>> UnknowRank(Map<String,Set<String>> MutantKillbyAsserts,int AssertNumber,List<String> FailingAssertion,
													  ArrayList<String> BugMethods,ArrayList<String> MethodsCoveredbyF,
													  ArrayList<String> types,String ID,String Project,String exceptiontype,String Level) throws IOException{

		
		
		
		ArrayList<List<Integer>> AllTypeRanks=new ArrayList<List<Integer>>();
		
		for(String type:types){
			Map<String, Double> MutantSus=new HashMap<String, Double>();  //mutatnt and its sus value
		    Map<String, ArrayList<Double>> MethodAllSus=new HashMap<String, ArrayList<Double>>(); //method and all its value
		    Map<String, Double> MethodSus=new HashMap<String, Double>();   //method and its selected value(max,all average)
			
			MutantSus=Spectrum.SuspiciousValue(MutantKillbyAsserts,FailingAssertion,AssertNumber,type); //one tech(ochia, or taratula...)
	        for(String mutant:MutantSus.keySet()){
	        	String Method=mutant.split(":")[0];
	            double score=MutantSus.get(mutant);
	           
	            if(!MethodAllSus.containsKey(Method)){
	            	ArrayList<Double> mutScores=new ArrayList<Double>();
	                mutScores.add(score);
	                MethodAllSus.put(Method,mutScores);
	            }else
	                MethodAllSus.get(Method).add(score);  
	        }
	        double totalscore=0;
	        for(String Method:MethodAllSus.keySet()){
	        	ArrayList<Double> allscores=MethodAllSus.get(Method);
	            double maxscore=Collections.max(allscores);
	            totalscore=totalscore+maxscore;
	            MethodSus.put(Method,maxscore);
	        }
	        
	        
	        //certain method in MethodsCoveredbyF may not have kill mutant, set 0
	        for(String m:MethodsCoveredbyF){
				if(!MethodSus.containsKey(m)){
					MethodSus.put(m,0.0);

				}
			}
	        
	        int bugsize=0;
			for(String bug: BugMethods){
				if (MethodsCoveredbyF.contains(bug)){
					if(MethodSus.containsKey(bug))
						bugsize++;
				}
			}
	        
	        List<Integer> Ranks=new ArrayList<Integer>();
	        
	        
	        Ranks=RankBySuspicious.RankMethod(MethodSus,BugMethods,MethodsCoveredbyF,ID,Project,type,exceptiontype,Level);
	    
			AllTypeRanks.add(Ranks);
		}
		return AllTypeRanks;
	}
}
