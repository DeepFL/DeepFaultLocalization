package Techs;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;

import Main.RunMain;

import java.io.*;

import ParseFiles.FilePath;


public class InformationR {
	public static String reg="[^a-zA-Z0-9]+";
	public static String replacechar="[\\]\\[(){},.;#:\"!?<>%/=]";
	public static String StopWords="abstract assert boolean break byte case catch char class const "
					      +"continue default do double else enum "
					      +"extends final finally float for goto if implements import instanceof int interface long native "
			              +"new package private protected public "
			       	      +"return short static strictfp super "
			       		  +"switch synchronized this "
			       		  +"throw throws transient try void "
			       		  +"volatile while null true false ";
	public static ArrayList<String> querys=new ArrayList<String>();
	public static void WritetoIndriFile(HashMap<String,StringBuilder> FailandMessage,HashMap<String,String> MethodandSourcecode,
			HashMap<String,String> TestandSourcecode,String Project,String ID,HashMap<String,String> MethodandIden) throws IOException{
		String BasePath=FilePath.InformationRData+Project+"/"+ID;
		 
		//String[] MethodInfor={"M","Mc"};            //Case1
		//String[] MethodInfor={"M","Mclmvcom"};      //Case2     
		String[] MethodInfor={"M","Mcl","Mm","Mv","Mcom"}; //Case3
		//String[] MethodInfor={"M","Mc","Mclmvcom","Mcl","Mm","Mv","Mcom"}; // All cases
		String[] TestInfor={"T","Tc","TFS"};
		int querySize=MethodInfor.length*TestInfor.length;
		for(String MInfor:MethodInfor){
			for(String TInfor:TestInfor)
				querys.add(MInfor+"to"+TInfor);
		}
		
		BufferedWriter[] BuildIndex=new BufferedWriter[querySize]; //build index parameter
		BufferedWriter[] Querys=new BufferedWriter[querySize];     //query parameters
		String[] indexPath=new String[querySize];
		String[] documents=new String[querySize];
		for(int i=0;i<querySize;i++){
			BuildIndex[i]=new BufferedWriter(new FileWriter(BasePath+"/"+querys.get(i)+"/IndexPara",true));
			Querys[i]=new BufferedWriter(new FileWriter(BasePath+"/"+querys.get(i)+"/queryPara",true));
			indexPath[i]=BasePath+"/"+querys.get(i)+"/Index";
			documents[i]=BasePath+"/"+querys.get(i)+"/Documents";
		}
		
		for(int i=0;i<querySize;i++){
			WriteFailing(i,Querys[i],FailandMessage,TestandSourcecode,indexPath[i],MethodandIden);
			WriteIndexpara(BuildIndex[i],indexPath[i],documents[i]);
			WriteDocuments(i,MethodandSourcecode,documents[i],MethodandIden);
		}
}
	public static void WriteFailing(int i,BufferedWriter bw,HashMap<String,StringBuilder> FailandMessage,HashMap<String,String> TestandSourcecode,
									String IndexPath,HashMap<String,String> MethodandIden) throws IOException{
		bw.write("<parameters>");
		bw.write("\n");
		bw.write("<index>");
		bw.write(IndexPath);
		bw.write("</index>"+"\n");
		
		int count=1;
		for(String key:FailandMessage.keySet()){
			if(TestandSourcecode.containsKey(key)){
				bw.write("<query>"+"\n");
				bw.write("<number>");
				bw.write(Integer.toString(count));
				bw.write("</number>"+"\n");
				bw.write("<text>");
				//if(i==0||i==3){    //failing test name
				if(querys.get(i).contains("toT")&&querys.get(i).split("toT").length==1){    //failing test name :"T"
					//String newkey=processMethodName(key);
					String newkey=RemovePrefix(key);
					String content=splitCamelCase(newkey.replaceAll(reg," "));
					bw.write(content+"</text>"+"\n");
				}
				//else if(i==2||i==5){    //Fail message
				else if(querys.get(i).contains("toTFS")){    //Fail message:  "TFS"
					String contents=splitCamelCase(FailandMessage.get(key).toString().replaceAll(RunMain.StacktracePrefix,"").replaceAll(reg," "));
					bw.write(contents+"</text>"+"\n");
				}

				else if(querys.get(i).contains("toTc")){    //fail source code
					if(TestandSourcecode.containsKey(key)){
						
						String content=splitCamelCase(TestandSourcecode.get(key).replaceAll(RunMain.StacktracePrefix,"").
								replaceAll(reg," "));
						bw.write(content+"</text>"+"\n");
					}
				}
				count++;
				bw.write("</query>");
			}
		}
		
		bw.write("\n");
		String remaining="<memory>256M</memory> <count>5000</count> <runID>runName</runID> <trecFormat>true</trecFormat>";
		bw.write(remaining);
		
		String[] stops=StopWords.split("\\s+");
		bw.write("<stopper>"+"\n");
		for(String st:stops){
			bw.write("<word>"+st+"</word>");
			bw.write("\n");
		}
		bw.write("</stopper>"+"\n");
		bw.write("<stemmer>"+"\n"+
				"<name>krovetz</name>"+"\n"+
				"</stemmer>");
		
		bw.write("</parameters>");
		
		bw.flush();
		bw.close();
	}
	public static void WriteIndexpara(BufferedWriter bw,String IndexPath,String DocPath) throws IOException{
		String staring="<parameters>"+"\n"+"<corpus>"+"\n"+"<path>";
		bw.write(staring);
		bw.write(DocPath+"</path>");
		bw.write("\n");
		bw.write("<class>trectext</class> </corpus> <index>");
		bw.write(IndexPath+"</index>"+"\n"+"<memory>256M</memory>");
		
		String[] stops=StopWords.split("\\s+");
		bw.write("<stopper>"+"\n");
		for(String st:stops){
			bw.write("<word>"+st+"</word>");
			bw.write("\n");
		}
		bw.write("</stopper>"+"\n");
		
		bw.write("<stemmer>"+"\n"+
		"<name>krovetz</name>"+"\n"+
		"</stemmer>");
		bw.write("</parameters>");
		bw.flush();
		bw.close();
	}
	public static void WriteDocuments(int i,HashMap<String,String> MethodandSourcecode,String DocPath,
											HashMap<String,String> MethodandIden) throws IOException{
	
		int count=1;
		BufferedWriter MethodID=new BufferedWriter(new FileWriter(DocPath+"/MethodID.txt",true));
		for(String m:MethodandSourcecode.keySet()){
			BufferedWriter bwdoc=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(DocPath+"/"+count+".txt"),"UTF-8"));
			bwdoc.write("<DOC>"+"\n"+"<DOCNO>");
			String docno="M-"+Integer.toString(count);
			MethodID.write(docno+":"+m);
			MethodID.write("\n");
			bwdoc.write(docno);
			bwdoc.write("</DOCNO>"+"\n"+"<TEXT>");
			//if(i==0||i==1||i==2){   //Method name
			if(querys.get(i).contains("Mto")){   //Method name:"M"
				//String newm=processMethodName(m);
				String newm=RemovePrefix(m);
				String content=splitCamelCase(newm.replaceAll(reg," "));
				bwdoc.write(content);
			}
			else if(querys.get(i).contains("Mclmvcom")){      //allfeature
				if(MethodandIden.containsKey(m)){
					if(!MethodandIden.get(m).contains("<allfeature></allfeature>")){
						String content=MethodandIden.get(m).split("<allfeature>")[1].split("</allfeature>")[0];
						String newcontent=splitCamelCase(content.replaceAll(reg," "));
						bwdoc.write(newcontent+"</text>"+"\n");
					}else
						bwdoc.write("</text>"+"\n");
				}
			}
			else if(querys.get(i).contains("Mclto")){    //class
				if(MethodandIden.containsKey(m)){
					if(!MethodandIden.get(m).contains("<ClassName></ClassName>")){
						String content=MethodandIden.get(m).split("<ClassName>")[1].split("</ClassName>")[0];
						String newcontent=splitCamelCase(content.replaceAll(reg," "));
						bwdoc.write(newcontent+"</text>"+"\n");
					}else
						bwdoc.write("</text>"+"\n");
				}
			}
			else if(querys.get(i).contains("Mmto")){   //method
				if(MethodandIden.containsKey(m)){
					if(!MethodandIden.get(m).contains("<MethodName></MethodName>")){
						String content=MethodandIden.get(m).split("<MethodName>")[1].split("</MethodName>")[0];
						String newcontent=splitCamelCase(content.replaceAll(reg," "));
						bwdoc.write(newcontent+"</text>"+"\n");
					}else
						bwdoc.write("</text>"+"\n");
				}
			}
			else if(querys.get(i).contains("Mvto")){    //variable
				if(MethodandIden.containsKey(m)){
					if(!MethodandIden.get(m).contains("<VariableName></VariableName>")){
						String content=MethodandIden.get(m).split("<VariableName>")[1].split("</VariableName>")[0];
						String newcontent=splitCamelCase(content.replaceAll(reg," "));
						bwdoc.write(newcontent+"</text>"+"\n");
					}else
						bwdoc.write("</text>"+"\n");
				}
			}
			else if(querys.get(i).contains("Mcomto")){       //comment
				if(MethodandIden.containsKey(m)){
					if(!MethodandIden.get(m).contains("<Comments></Comments>")){
						String content=MethodandIden.get(m).split("<Comments>")[1].split("</Comments>")[0];
						String newcontent=splitCamelCase(content.replaceAll(reg," "));
						bwdoc.write(newcontent+"</text>"+"\n");
					}else
						bwdoc.write("</text>"+"\n");
				}
			}
			else if(querys.get(i).contains("Mcto")){  //Method source code :"Mc"
				String content=splitCamelCase(MethodandSourcecode.get(m).replaceAll(RunMain.StacktracePrefix,"").replaceAll(reg," "));
				
				bwdoc.write(content);
			}
			bwdoc.write("\n");
			bwdoc.write("</TEXT>"+"\n"+"</DOC>");
			count++;
			bwdoc.flush();
			bwdoc.close();
		}
		MethodID.flush();
		MethodID.close();
	}
	public static String splitCamelCase(String s) {
		String a=s.replaceAll(
				String.format("%s|%s|%s",
						"(?<=[A-Z])(?=[A-Z][a-z])",
						"(?<=[^A-Z])(?=[A-Z])",
						"(?<=[A-Za-z])(?=[^A-Za-z])"
						), " ");
		String newString=s+" "+a;
		return length3(newString);
	}
	public static String length3(String s){
		String[] items=s.split("\\s+");
		StringBuilder finalString=new StringBuilder();
		for(String i:items){         //only consider string with length>2
			if(i.length()>2)
				finalString.append(i+" ");
		}
		return finalString.toString();
	}
	public static String processMethodName(String methodName){
		String items[]=methodName.split("\\.");
		int indexlast=items.length-1;
		int index2=items.length-2;
		String NewName=items[index2]+"."+items[indexlast];
		return NewName;
	}
	public static String RemovePrefix(String contents){
		return contents.replaceAll(RunMain.StacktracePrefix,"");
	}
}
