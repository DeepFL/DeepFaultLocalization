package Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import Main.RunMain;

import java.io.IOException;
import java.util.*;

public class RankBySuspicious {
	public static List<Integer> RankMethod(Map<String, Double> SuspiciousValues,ArrayList<String> BugMethods,ArrayList<String> MethodsCoveredbyF,
										   String ID,String Project,String type,String exceptiontype,String Level) throws IOException{
		TreeMap<Double, Set<String>> Rank = new  TreeMap<Double, Set<String>>();
	    for(String method: SuspiciousValues.keySet()){
	    	if(MethodsCoveredbyF.contains(method)){
	    		double value=SuspiciousValues.get(method);
	    		if(!Rank.containsKey(value)){
	    			Set<String> Meths=new HashSet<String>();
	    			Meths.add(method);
	    			Rank.put(value,Meths);
	    		}else{
	    			Rank.get(value).add(method);
	    		}
	    	}
	    }
	    NavigableMap<Double, Set<String>> FinalMap=Rank.descendingMap();
	    RunMain.WriteSuspicous(FinalMap, ID, Project, type, exceptiontype,Level);
	    
	    
	    List<Integer> Ranks=new ArrayList<Integer>();
		for(String bug: BugMethods){
			if (MethodsCoveredbyF.contains(bug)){
				if(SuspiciousValues.containsKey(bug)){
					
					
					double susvalue=SuspiciousValues.get(bug);
					
					int rank=RankFinal(FinalMap,susvalue);
					
					Ranks.add(rank);
				}
			}
		} 
		Collections.sort(Ranks);
		return Ranks;
	}
	public static int RankFinal( NavigableMap<Double, Set<String>> FinalMap,double susvalue){
		int rank=0;
        for(double key:FinalMap.keySet()){
        	int compares=Double.compare(key,susvalue);
        	if(compares>0||compares==0)
        		rank=rank+FinalMap.get(key).size();    
        }
        return rank;
	}
}
