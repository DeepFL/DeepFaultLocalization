package Utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.zip.GZIPInputStream;

import Main.RunMain;
import ParseFiles.MutationParser;
import ParseFiles.ReadFiles;

/*
 * 
 * 
 * Write to  mutator 
 * 
 * 
 * 
 * mutator 1: all mutants covered and not coverd by tests
 * mutator 2: mutants only covered by tests
 * mutator 3: mutatnts only covered by failed tests
 *
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
public class WriteAllMutator {
	
	public static void CountMutant(String readPath,String writePath) throws IOException{
		
		//17 mutator1+17 mutator2+17 mutator3
		HashMap<String,ArrayList<String>> MethodandAllMutator=new HashMap<String,ArrayList<String>>();
		//Text file
		BufferedReader br = new BufferedReader(new FileReader(readPath));
		MethodandAllMutator=parseMutator(br);
		br.close();
		WriteMutator(MethodandAllMutator,writePath);
	}
	public static HashMap<String,ArrayList<String>> parseMutator(BufferedReader br) throws IOException{
		HashMap<String,ArrayList<String>> MethodandAllMutator=new HashMap<String,ArrayList<String>>();
		String line="";
		line=br.readLine();
		while(line!=null){
			if(line.contains("MutationDetails")){
				String useforMutants=MutationParser.parseMutants(line);
				String[] items=useforMutants.split("&");
				String MethodName=items[5]+"."+items[4]+items[0].split("MutationDetails")[1];
				String MethodLine=items[5]+"."+items[4]+":"+items[3];
				
				String mutator=items[1].split("\\_")[0];
				
				String Tempmutator="";
				
				 /* mutator1=type1+type2+type3
				    mutator2=type2+type3
				    mutator3=type3
				*/
				
				if(line.contains("testsInOrder=Y")){   //covered by tests
					if(RunMain.StatementsCoverdbyF.contains(MethodLine))
						Tempmutator=mutator+"+type3";        //only covered by failtest
					else
						Tempmutator=mutator+"+type2"; 	     //covered by Tests
				}else if(line.contains("testsInOrder=N"))
					Tempmutator=mutator+"+type1";
				if(!MethodandAllMutator.containsKey(MethodName)){
					ArrayList<String> mutators=new ArrayList<String>();
					mutators.add(Tempmutator);
					
					MethodandAllMutator.put(MethodName,mutators);
				}else
					MethodandAllMutator.get(MethodName).add(Tempmutator);
				
			}
			line=br.readLine();
		}
		return MethodandAllMutator;
	}
	public static void WriteMutator(HashMap<String,ArrayList<String>> MethodandAllMutator,
									String writepath) throws IOException{
		int mutatorSize=RunMain.Allmutators.size();
		//Final
		HashMap<String,ArrayList<Integer>> FinalMethodandMutator=new HashMap<String,ArrayList<Integer>>();
		for(String Method:MethodandAllMutator.keySet()){
			int[] AllCount=new int[mutatorSize+1];  //all mutants +total 
			int[] AllCoverCount=new int[mutatorSize+1]; //covered by tests
			int[] FailCoverCount=new int[mutatorSize+1]; //covered only by fail tests
			ArrayList<String> mutators=MethodandAllMutator.get(Method);
			for(String mu:mutators){
				String muta=mu.split("\\+")[0];
				int index=RunMain.Allmutators.indexOf(muta);
				if(mu.contains("type3")){
					AllCount[index]=AllCount[index]+1;
					AllCoverCount[index]=AllCoverCount[index]+1;
					FailCoverCount[index]=FailCoverCount[index]+1;
				}else if(mu.contains("type2")){
					AllCount[index]=AllCount[index]+1;
					AllCoverCount[index]=AllCoverCount[index]+1;
				}else if(mu.contains("type1")){
					AllCount[index]=AllCount[index]+1;
				}
			}
			ArrayList<Integer> combineCount=new ArrayList<Integer>();
			int sumAll=0;
			int sumAllcover=0;
			int sumFailcover=0;
			for(int i=0;i<AllCount.length-1;i++){
				sumAll=sumAll+AllCount[i];
				sumAllcover=sumAllcover+AllCoverCount[i];
				sumFailcover=sumFailcover+FailCoverCount[i];
			}
			AllCount[mutatorSize]=sumAll;
			AllCoverCount[mutatorSize]=sumAllcover;
			FailCoverCount[mutatorSize]=sumFailcover;
			for(int c:AllCount)
				combineCount.add(c);
			for(int c:AllCoverCount)        //mutator 2
				combineCount.add(c);
			for(int c:FailCoverCount)		//mutator 3
				combineCount.add(c);
			FinalMethodandMutator.put(Method,combineCount);
		}
		
		BufferedWriter bw=new BufferedWriter(new FileWriter(writepath));
		for(String Method:FinalMethodandMutator.keySet()){
			ArrayList<Integer> countMutator=FinalMethodandMutator.get(Method);
			bw.write(Method+" ");
			for(int c:countMutator){
				bw.write(c+",");
			}
			bw.write("\n");
		}
		bw.flush();
		bw.close();
		
	}
	
	
	

}
