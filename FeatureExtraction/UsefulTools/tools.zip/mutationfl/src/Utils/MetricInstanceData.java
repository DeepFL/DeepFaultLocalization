package Utils;
import ParseFiles.BugMethodParser;
import ParseFiles.FilePath;
import Techs.getMethodMetrics;

import java.io.*;
import java.util.*;

import Main.RunMain;


/*
 * Two BaseLines: Spectrum, SpectrumTest
 * BaseLine+Different Metrics,   args[7]
*  write baseline and metrics together, can use 
 */

public class MetricInstanceData {
	public static ArrayList<String> orderedfeature=new ArrayList<String>();
	public static void main(String[] args) throws IOException{
		
		String FeatureIDpath=args[0];
		String Project=args[1];
		String ID=args[2];
		String Susvaluepath=args[3];   //..../suspvalue/Lang/1
		String GlobalIDpath=args[4];
		String Writepath=args[5];
		
		
		ArrayList<String> BugMethods = BugMethodParser.BugMethod(FilePath.Bugpath + Project + "/" + ID + ".txt");
		
		HashMap<String,String> featureID = ReadfeatureID(FeatureIDpath,"feature");// feature1->id1,feature2->id2..
		int featuresize=featureID.size();   //base line size
		HashMap<String,String> GlobalID=ReadfeatureID(GlobalIDpath,"global");// project1->id1,project2->id2..
		
		HashMap<String,StringBuilder> Instance=ReadSus(featureID,Susvaluepath,ID,Project,BugMethods,GlobalID);// BaseLine
		
		
		HashMap<String,ArrayList<String>> ByteMethodandMetrics=readMutatorFile(FilePath.JhawkPath+Project+"/"+ID+".txt","Jhawk");
		HashMap<String,ArrayList<String>> MethodandByteMetric=readMutatorFile(FilePath.ByteMetricPath+Project+"/"+ID+".txt","Byte");
		HashMap<String,ArrayList<String>> MethodandIRMetric=readMutatorFile(FilePath.IRDataPath+Project+"/"+ID+".txt","IR");
		HashMap<String,ArrayList<String>> methodAndAggreMetric=readMutatorFile(FilePath.aggreSpectrumDataPath+Project+"/"+ID+".txt","aggreSpectrum");
		HashMap<String,ArrayList<String>> FluccsByteMethodandMetrics=readMutatorFile(FilePath.FluccsJhawkPath+Project+"/"+ID+".txt","Jhawk");
		HashMap<String,ArrayList<String>> FluccsMethodandByteMetric=readMutatorFile(FilePath.FluccsBytePath+Project+"/"+ID+".txt","Byte");
		HashMap<String,ArrayList<String>> findbugsMetric=readMutatorFile(FilePath.findbugsPath+Project+"/"+ID+".txt","findbugs");
		
		ArrayList<HashMap<String,ArrayList<String>>> CombineMap=new ArrayList<HashMap<String,ArrayList<String>>>();


		int[] Fsize={21,16,15}; // 21 jhawk, 16 byte,15 IR
		CombineMap.add(ByteMethodandMetrics);
		CombineMap.add(MethodandByteMetric);
		CombineMap.add(MethodandIRMetric);
		addMultipleMetrics(Instance,CombineMap,featuresize,Fsize);
	
		WritetoFile(Instance, Writepath);
		
	}
	
	
	public static void combineclass(HashMap<String,StringBuilder> Ins,
									HashMap<String,ArrayList<String>> Map2,int featuresize){
		for(String Method:Ins.keySet()){
			int lastindex=Method.lastIndexOf(".");
			String Classname=Method.substring(0, lastindex);
			if(Map2.containsKey(Classname)){  //ClassMetrics
				int featureID=featuresize;
				ArrayList<String> Metrics=Map2.get(Classname);
				for(String metri:Metrics){
					if(!metri.contains("N/A"))
						Ins.get(Method).append(featureID+":"+metri+" ");
					featureID++;
				}
			}
		}
		
	}
	public static HashMap<String,ArrayList<String>> addclassMetrics(HashMap<String,StringBuilder> Ins,int MetricBegin){
		HashMap<String,ArrayList<String>> ClassMetric=new HashMap<String,ArrayList<String>>(); 
		String splitS=MetricBegin+":";   
		for(String Method:Ins.keySet()){      //loop instance
			int lastindex=Method.lastIndexOf(".");
			String Classname=Method.substring(0, lastindex);
			StringBuilder metrics=Ins.get(Method);   //baseline+other metrics
			String values=splitS+metrics.toString().split(splitS)[1];  //vauls only metrics, no baseline
			String[] allmets=values.split(" ");
			if(!ClassMetric.containsKey(Classname)){
				ArrayList<String> mets=new ArrayList<String>();
				for(String eachV:allmets)
					mets.add(eachV.split(":")[1]);
				ClassMetric.put(Classname, mets);
			}
			else{
				ArrayList<String> ms=ClassMetric.get(Classname);   // already in classandMetrics
				ArrayList<String> newms=new ArrayList<String>();  //new
				for(int i=0;i<ms.size();i++){
					String alreadyValue=ms.get(i);
					String newvalue=allmets[i].split(":")[1];
					if(!alreadyValue.contains("N/A")&&!newvalue.contains("N/A")){
						Double value=Double.parseDouble(ms.get(i))+Double.parseDouble(allmets[i].split(":")[1]);
						newms.add(Double.toString(value));
					}else if(!alreadyValue.contains("N/A")&&newvalue.contains("N/A")){
						newms.add(alreadyValue);
						
					}else if(alreadyValue.contains("N/A")&&!newvalue.contains("N/A")){
						newms.add(newvalue);
						
					}else if(alreadyValue.contains("N/A")&&newvalue.contains("N/A")){
						newms.add("N/A");
					}
				}
				ClassMetric.put(Classname, newms);
			}
		}
		return ClassMetric;
		
	}
	
	public static HashMap<String,ArrayList<String>> readMetriFile(String FilePath,String type) throws IOException{
		HashMap<String,ArrayList<String>> MethodandMutator=new HashMap<String,ArrayList<String>>();
		BufferedReader br=new BufferedReader(new FileReader(FilePath));
		String line=br.readLine();
		while(line!=null){
			String Method=line.split(" ")[0];
			String[] vas=line.split(" ")[1].split(",");
			ArrayList<String> values=new ArrayList<String>();
			if(type.equals("Mutor1")){ //0-16
				for(int i=0;i<17;i++)
					values.add(vas[i]);
			}else if(type.equals("Mutor12")){ //0-33
				for(int i=0;i<34;i++)
					values.add(vas[i]);
			}else if(type.equals("Mutor123")){ //0-50
				for(int i=0;i<51;i++)
					values.add(vas[i]);
			}
			MethodandMutator.put(Method,values);
			line=br.readLine();
		}
		br.close();
		return MethodandMutator;
	}
	

	//Can be used to get byte metric and Jhawk data
	public static HashMap<String,ArrayList<String>> readMutatorFile(String FilePath,String type) throws IOException{
		HashMap<String,ArrayList<String>> MethodandMutator=new HashMap<String,ArrayList<String>>();
		BufferedReader br=new BufferedReader(new FileReader(FilePath));
		String line=br.readLine();
		while(line!=null){
			String Method=line.split(" ")[0];
			ArrayList<String> values=new ArrayList<String>();
			if(type.equals("Mutor")||type.equals("Jhawk")||type.equals("IR")||type.equals("aggreSpectrum")
					||type.equals("findbugs")){
				String[] vas=line.split(" ")[1].split(",");
				for(String va:vas)
					values.add(va);
			}
			else if(type.equals("Byte")){
				String[] items=line.split(" ");
				for(int i=1;i<items.length;i++)
					values.add(items[i]);
			}else{
				System.out.println("parameter error!");
			}
			ArrayList<String> vs=new ArrayList<String>();
			for(String v:values)
				vs.add(v);
			MethodandMutator.put(Method, vs);
			line=br.readLine();
		}
		br.close();
		return MethodandMutator;
	}

	public static void addMultipleMetrics(HashMap<String,StringBuilder> Instance,
										 ArrayList<HashMap<String,ArrayList<String>>> techsandMetrics,
										 int featuresize,int[] Fsize){
		for(String Method:Instance.keySet()){
			int featureID=featuresize+1;
			for(int i=0;i<techsandMetrics.size();i++){
				HashMap<String,ArrayList<String>> techMetrics=techsandMetrics.get(i);// jhaw metrics or byte metrics or...
				if(techMetrics.containsKey(Method)){
					ArrayList<String> Metrics=techMetrics.get(Method);
					for(String metri:Metrics){
						Instance.get(Method).append(featureID+":"+metri+" ");
						featureID++;
					}
				}else{
					int thisfeaturesize=Fsize[i];
					for(int s=0;s<thisfeaturesize;s++){
						Instance.get(Method).append(featureID+":"+"N/A"+" ");  
						featureID++;											
					}
				}
			}
		}
	}
	
	

	
	public static HashMap<String,String> ReadfeatureID(String path,String fg) throws IOException{
		BufferedReader br1=new BufferedReader(new FileReader(path));
		String line=br1.readLine();
		HashMap<String,String> featureID=new HashMap<String,String>();
		
		while(line!=null){
			if(fg.contains("feature")){
				featureID.put(line.split("\\s+")[1],line.split("\\s+")[0]);
				orderedfeature.add(line.split("\\s+")[1]);
			}
			else
				featureID.put(line.split("\\s+")[0],line.split("\\s+")[1]);
			line=br1.readLine();
		}
		br1.close();
		return featureID;
	}
	public static HashMap<String,StringBuilder> ReadSus(HashMap<String,String> FeatureID,String basepath,String ID,
								String Project,ArrayList<String> BugMethods,
								HashMap<String,String> globalPID) throws IOException{
		HashMap<String,StringBuilder> Instance=new HashMap<String,StringBuilder>();
		File folder = new File(basepath);
		File[] listOfFiles = folder.listFiles();
		ArrayList<String> currentfeatures=new ArrayList<String>();
		for (int i = 0; i < listOfFiles.length; i++) {
			currentfeatures.add(listOfFiles[i].getAbsolutePath());
		}
		
		
		for (String feature:orderedfeature) {
			String path=basepath+feature+".txt";
			if(currentfeatures.contains(path)){
				BufferedReader br1=new BufferedReader(new FileReader(path));// each of 29 sus values
				String line=br1.readLine();
			
				String featureID=FeatureID.get(path.split(".txt")[0].substring(path.lastIndexOf("/")+1));
				String PID=globalPID.get(Project+"-"+ID);
				while(line!=null){
					String Method=line.split(" ")[0];
					String value=line.split(" ")[1];
					if(!value.equals("NaN")){
						if(!Instance.containsKey(Method)){
							StringBuilder data=new StringBuilder();
							if(BugMethods.contains(Method)) {
								data.append("1 ");
							}
							else {
								data.append("0 ");
							}

							data.append("qid:"+PID+" "+featureID+":"+value+" ");

							Instance.put(Method, data);
						}else
							Instance.get(Method).append(featureID+":"+value+" ");
					}
					line=br1.readLine();
				}
				br1.close();
			}
		}
		return Instance;
	}
	public static void WritetoFile(HashMap<String,StringBuilder> Instance,String Writepath) throws IOException{
		BufferedWriter bw=new BufferedWriter(new FileWriter(Writepath,false));
		for(String Method:Instance.keySet()){
			String[] values=Instance.get(Method).toString().trim().split(" ");
			for(int i=0;i<values.length-1;i++){
				if(!values[i].contains("N/A"))
					bw.write(values[i]+" ");
			}
			if(!values[values.length-1].contains("N/A"))
				bw.write(values[values.length-1]);
			bw.write("\n");
		}
		bw.flush();
		bw.close();
	}

}
