package Utils;
import ParseFiles.*;
import Main.*;
import java.io.*;
import java.util.*;

public class PrintResults {
	public static void PrintFinalResult(ArrayList<List<Integer>> SpectrumResult, 
										ArrayList<ArrayList<List<Integer>>> UnknowResults,
										
										String ID,String Project,String Level) throws IOException{
		BufferedWriter bw = null;		  
	    
	    File file = new File(FilePath.ResutPath+Project+"/"+Level+"Level.csv");
	    FileWriter fw = new FileWriter(file,true);
		bw = new BufferedWriter(fw);
	    bw.write(ID+",");
	    for(List<Integer> r:SpectrumResult)
	    	PrintResult(r,bw);
		for(int i =0;i<RunMain.fourheros;i ++){
			
			ArrayList<List<Integer>> unknowResultss=UnknowResults.get(i);
			for(List<Integer> Ranks:unknowResultss)
				PrintResult(Ranks,bw);	
			
		}
		bw.write("\n");
	    bw.flush();
	    bw.close();  	
	}
	public static void PrintResult(List<Integer> Ranks,BufferedWriter bw)throws IOException{
		int RankSum=0;
		double rankaverage=0.0;
		int size=Ranks.size();
		/*for(int rank:Ranks){
			System.out.print(rank+" ");
		}*/
		
		/*if(size==1)
			bw.write(Integer.toString(Ranks.get(0))+",");
		else if(size>1){
			for(int rank:Ranks) 
				RankSum=RankSum+rank;
	
			rankaverage=(double)RankSum/size ; 
			bw.write(Double.toString(rankaverage)+",");*/
		for(int rank:Ranks)
			bw.write(Integer.toString(rank)+" ");
		bw.write(",");
	}
}
